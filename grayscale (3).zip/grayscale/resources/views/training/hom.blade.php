@extends('layouts.app')

@section('content')

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" style="font-size: 1.5em; font-weight: bolder; color: blue; background-color: white" align="center"><img src="http://codespace.com.ng/img/bg1.png" style="width:25%" align="left"/>
                 <br> Grayscale International Gsi<br>
                    <small style="color: black"><i>The Master class & Mentorship Series</i></small>
                </div>
            </div></div><div class="container">
            <div class="row">
                <div class="col-md-12 jumbotron">
                    <h2>The GSi MasterClass Series</h2>
                    <div class="panel" align="justify">
                       <p> At GSi, we believe mentorship reduces the effort practitioners expend to attain professional success. Our masterclass will equip participants with the skills to drive personal and professional development through direct interactions with experts. Mentees will own their development and learn life-long success habits.
                        </p> <p> At the moment, our mentorship series focuses on Medical Imaging & Radiation Therapy to equip health professionals to translate their
                           <a href="/entrep" style="color:blue; text-decoration: underline">entrepreneurship,</a>  <a href="/academic" style="color:blue; text-decoration: underline">academic</a> or professional potential into their expected reality for patients benefit. We hold the view that potentials are unspent qualities at best and ordinarily untested. On the other hand, to be distinguished is to have utilised and kineticised one's potentials to the fullest with visible results.
                        </p> <p>This masterclass series focuses on improving medical imaging and radiation professionals output in developing countries, especially those in Africa. We acknowledge that constraining environmental challenges mostly overtake these professionals. That they seldom have professional mentors to accelerate their growth. The program's duration is typically three months long and runs quarterly. On completion, participants would choose to remain within the alumni network for continuous learning and experience sharing.
                        </p><p> <a href="/cdetails" style="color:blue; text-decoration: underline">Click here </a> for more information on this Gsi Mentorship series.
</p>

                    </div>

                </div>
            </div>


        </div>
    @endsection
