@extends('layouts.app')

@section('content')
    <script>
        function printDiv() {
            var divContents = document.getElementById("GFG").innerHTML;
            var a = window.open('', '', 'height=900, width=1200');
            a.document.write('<html>');
            a.document.write('<body > <h1>List of Registrants <br>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }

    </script>
<?php
$servername = "localhost";
$username = "grayscal_grayscale";
$password = "GRAYSCALE2020";
$dbname = "grayscal_grayscaledb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM surveys";
$result = $conn->query($sql);
?>
    <div class="container">
        <a href="/" class="btn btn-warning text-decoration-none">Go Home</a>
        <h1 align="center">Survey Response</h1>
        <div class="row">
            <div class="col-md-12 card1" style="margin: auto" id="all">
        
                   <table style="width:100%" width="100%">
                        <tr>
                           <td align="center"><br>
                                <button onclick="printDiv()" id="printa"  class="btn btn-success btn-sm"><i class="fa fa-print"></i> Print List</button> </td>
                        </tr>
                   </table>
                    <div  id="GFG" align="center" style="overflow:scroll">
                        <table class="table table-hover table-striped table-bordered" align="center"  id="GFG" style="width:100%; background-color:#eee">
                            <tr>
                                <td>
                                    SEX
                                </td>
                                <td>
                                    COUNTRY
                                </td>
                                <td>
                                    AGE
                                </td>
                                <td>
                                QUALIFICATION
                                </td>
                                <td>
                                    ACADEMIC
                                </td><td>
                                    YEARS
                                </td> <td>
                                  OWN BUSINESS?
                                </td>
                                <td>
                                   YEARS IN BUSINESS
                                </td>
                                <td>
                                   BUSINESS EQUIPMENT
                                </td>
                                <td>
                                    STARTUP CAPITAL
                                </td>
                                <td>
                                    BUSINESS VALUE
                                </td>
                                <td>
                                    TOP BIZ NEEDS
                                </td>
                                <td>
                                    TOP CUSTOMER NEEDS
                                </td>
                                <td>
                                   NEXT EQUIPMENT
                                </td>
                                <td>
                                    STAFF No.
                                </td>
                                <td>
                                   EXPERIENCE
                                </td>
                                <td>
                                    STRATEGIC NEED
                                </td>
                            </tr>
                            <?php
                          
  // output data of each row
  if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      ?>
                                <tr>
                                    <td><?=$row["sex"];?></td>
                                    <td><?=$row["country"];?></td>
                                    <td><?=$row["age"];?></td>
                                    <td><?=$row["qualification"];?></td>
                                    <td><?=$row["academic"];?></td>
                                    <td><?=$row["years"];?></td>
                                    <td><?=$row["do"];?></td>
                                    <td><?=$row["start"];?></td>
                                    <td><?=$row["equipment"];?> 
                                            </td>
                                    <td><?=$row["capital"];?></td>
                                    <td><?=$row["current"];?></td>
                                    <td>
                                      <?=$row["bizneed"];?></td>
                                    <td><?=$row["cusneed"];?>
                                                </td>
                                    <td><?=$row["next"];?></td>
                                    <td><?=$row["staff"];?></td>
                                    <td><?=$row["experience"];?></td>
                                    <td><?=$row["strategic"];?></td>
                                </tr>
                     <?php      
      
  }
} else {
  echo "0 results";
}
$conn->close();
?>
                        </table>
                

                            
               
                    </div>
            </div>
        </div>
</div>

@endsection
