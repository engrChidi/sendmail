@extends('layouts.app')

@section('content')
<div class="container mb-5">
    <div class="home">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-5">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    <a href="/post/create" class='btn btn-primary mt-3 mb-5'>Create Post</a>
                    <a href="/project/create" class='btn btn-primary mt-3 mb-5'>Create Project</a>
                    <a href="/event/create" class='btn btn-primary mt-3 mb-5'>Create Event</a>
                    <div class="row">
                        <div class="col-md-12">
                            <nav>
                                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Posts</a>
                                    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Projects</a>
                                    <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Events</a>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    @if(count($posts) > 0)
                    <table class="table table-striped">
                        <tr>
                            <th>Image</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        @foreach($posts as $post)
                        <tr>
                            <th><img src="/storage/cover_images/{{$post->cover_image}}" alt="" style="width: 100px; height:100px; object-fit:cover"></th>
                            <th><a href="/post/{{$post->id}}" class="text-decoration-none">{{$post->title}}</a></th>
                            <th><a href="/post/{{$post->id}}/edit" class="btn btn-success">Edit</a></th>
                            <th>
                                {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']) !!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
                                {!!Form::close()!!}
                            </th>
                        </tr>
                        @endforeach
                    </table>

                    @else


                    @endif
                </div>
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                    @if(count($projects) > 0)
                    <table class="table table-striped">
                        <tr>
                            <th>Image</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        @foreach($projects as $project)
                        <tr>
                            <th><img src="/storage/cover_images/{{$project->cover_image}}" alt="" style="width: 100px; height:100px; object-fit:cover"></th>
                            <th><a href="/post/{{$project->id}}" class="text-decoration-none">{{$project->title}}</a></th>
                            <th><a href="/post/{{$project->id}}/edit" class="btn btn-success">Edit</a></th>
                            <th>
                                {!!Form::open(['action' => ['ProjectController@destroy', $project->id], 'method' => 'POST', 'class' => 'pull-right']) !!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
                                {!!Form::close()!!}
                            </th>
                        </tr>
                        @endforeach
                    </table>

                    @else


                    @endif
                </div>
                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                    @if(count($events) > 0)
                    <table class="table table-striped">
                        <tr>
                            <th>Image</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        @foreach($events as $event)
                        <tr>
                            <th><img src="/storage/cover_images/{{$event->cover_image}}" alt="" style="width: 100px; height:100px; object-fit:cover"></th>
                            <th><a href="/post/{{$event->id}}" class="text-decoration-none">{{$event->title}}</a></th>
                            <th><a href="/post/{{$event->id}}/edit" class="btn btn-success">Edit</a></th>
                            <th>
                                {!!Form::open(['action' => ['EventController@destroy', $event->id], 'method' => 'POST', 'class' => 'pull-right']) !!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
                                {!!Form::close()!!}
                            </th>
                        </tr>
                        @endforeach
                    </table>

                    @else


                    @endif
                </div>
            </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
@endsection
