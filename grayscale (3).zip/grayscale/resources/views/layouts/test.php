@extends('layouts.app')

@section('content')
<header>
        <div class="container">
                <div class="row hero-text">
                        <div class="col-md-6">
                                <h1>At GSI we create the important linkage of outcomes driven adjustments on existing health strategies, population health benefits and stakeholders expectations
                                </h1>
                                <i class="fa fa-twitter"></i>
                                <i class="fa fa-instagram"></i>
                                <i class="fa fa-facebook"></i>
                        </div>
                        <div class="col-md-6 logo mb-3">
                                <img src="{{ asset('images/logo.png') }}" alt="" class="logo">
                        </div>
                </div>
        </div>
</header>
<section class="event pt-5">
        <div class="container">
                <h2 class="mb-4 mt-3 pl-3"><strong>New Events</strong></h2>
                @if(count($posts) > 0)
                <div class="row">

                        @foreach($posts as $post)
                        <div class="col-md-4 mb-3">
                                <div class="card">
                                        <img src="/storage/cover_images/{{$post->cover_image}}" alt="" style="width: 100%">
                                        <h1><a href="/post/{{$post->id}}" class="text-decoration-none">{{$post->title}}</a></h1>
                                        <small>Written at {{$post->created_at}}</small>
                                </div>
                        </div>

                        @endforeach

                </div>

                @else

                @endif
                <a href="/post" class="btn btn-primary mt-5">See more</a>
        </div>
</section>
<section class="about container" id="about">
        <h2 class="pl-3"><strong>About Us</strong></h2>
        <div class="row">
                <div class="col-md-12">
                        <p>GrayScale International (GSI) is a response to the gaps created by the ailing health system in low-to-mid income countries especially in Africa. GSI blends both for-the-profit and social enterprise strategies to strengthen health systems, utilise loco-regional evidence base to improve service and operational efficiency or effectiveness of a specific health program, drive the integration of innovative and sustainable products and services which result to the attainment of our partner-specific health outcomes. We do so by delivering on our partners and stakeholders priorities, upholding our core values of integrity, inclusiveness, team-winning, people's leadership and LEAN operations. GSI empowers communities by helping her partners and collaborators to deliver results in moments that matters regardless of prevailing uncertainties.
                        </p>
                </div>
        </div>
        <h3 class="pl-3"><strong>Our Mission</strong></h3>
        <div class="row">
                <div class="col-md-12">
                        <p>
                                GrayScale International (GSI) creates important linkage of outcomes driven adjustments to existing health strategies. By leaveraging data, we strengthen health system, improve performance and service efficiencies, build capacity and stimulate change for improve health service effectiveness.
                        </p>
                </div>
        </div>
</section>
<section class="services" id="services">
        <div class="container">
                <div class="row">
                        <div class="col-md-6">
                <h2 class="pl-3"><strong>Our Services</strong></h2>
                <p>Our Services/Products include but not limited to the following</p>
                <ol>
                        <a href="/#training"><li>Training and capacity development in Health.</li></a>
                        <a href="/#prevent"><li>Screening and Preventive Health.</li></a>
                        <a href="/#implement"><li>Implementation and Outcome research.</li></a>
                        <a href="/#radio"><li>Radiography and Medical Imaging service development.</li></a>
                        <a href="/#health"><li>Healthcare Consultancy and General suppliers services.</li></a>
                </ol>
                        </div>
                        <div class="col-md-6">
                                <img src="./images/health.jpg" alt="service-img" class="service-img">
                        </div>
                </div>
        </div>
</section>

<section class="train" id="training" style="background-image: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url(../images/health.jpg); background-size: cover; background-position: center; color: #fff; padding: 100px 0px">
        <div class="container">
                <h3><strong>Training and capacity development in health</strong></h3>
                <p>The health and care practice is constantly evolving in line with emerging evidence therefore health and care professionals are required to continuously improve on their professional development so that members of their communities receive quality healthcare services. This requirement, however basic, is not attainable in many developing nations due to the gap in human resource engineering i.e shortage of skill and number of HCW, knowledge gaps, lack of appropriate motivation, lack of specialization routes, lack of a local mechanism to integrate emerging evidence-based into practice, underfunding of their learning and development.</p>
                <p>
                        GSI draws from her experience from 13 African countries to build capacity to develop and deploy service-oriented and outcomes tailored learning and capacity modules in a wide range of applicable subject. Building capacity at primary and secondary levels facilities to integrate technology-aided care is its core strength. Examples include building capacity for midwives to integrate limited obstetrics ultrasound (LOU) into their practice, enabling the nurse to utilise baby warmers, neonatal resuscitation devices, phototherapy units in the care and management of sick new-borns or training community health officers and junior doctors to use utilise electrocardiographic ECG machines and basic echocardiography assessment of the sick adult to detect danger signs early.
                </p>
                <p>
                        How we deliver; we adopt a blended learning approach leveraging the strengths of
                        <ol>
                                <li>
                                        E-learning.
                                </li>
                                <li>
                                        Competency based assessment test.
                                </li>
                                <li>
                                        Service level mentorship targeted to build specific service capability into the routine service delivery of the health facility.
                                </li>
                        </ol>
                </p>
        </div>
</section>

<div class="row">
<div class="col-md-6">
<section class="health-consultancy" id="health">
        <div class="container">
                <h3><strong> Health Consultancy services</strong></h3>
                <p>
                        GSI offers the following as consultancy services:
                        <ol>
                                <li>Health Portfolio Management</li>
                                <li>Scale-up of pilot programs (advisory and program implementation) leading to fully devolved interventions</li>
                                <li>Program Management and Implementation</li>
                                <li>Implementation Research (Monitoring and evaluating services) for health</li>
                                <li>Health Promotion and community Immersion</li>
                        </ol>
                </p>
        </div>
</section>
</div>
<div class="col-md-6">
<section class="implementation" id="implement">
        <div class="container">
                <h3><strong>Implementation and Outcomes research</strong></h3>
                <p>GSI is positioned to drive evidence base improvement that promotes real health outcomes. Broadly we assist our partners and collaborators to:
                        <ol>
                                <li>Perform Field data management from Countries in Africa</li>
                                <li>Conduct implementation research related to product and programs effectiveness in the African context. Our outputs readily support market access for these products and services.</li>
                                <li>Coordinate a network of associates for multicountry implementation research based on the requirement of our customer/partners.</li>
                                <li>Drive the devolution of evidence-based into routine service offering (level 1 and level 2 translational research implementation).</li>
                        </ol>
                </p>
        </div>
</section>
</div>
</div>

<div class="row">
        <div class="col-md-6">
<section class="radiography" id="radio">
        <div class="container">
                <h3><strong>Radiography development</strong></h3>
                <p>Medical imaging and radiography in Africa are still developing. Gaps in academic radiography translate into weak professional practice and professionalism in the health sector. The emergence of Artificial intelligence AI, public health radiography and consultant practice (advance practice) further challenges radiography development in Africa.</p>
                <p>GSI bridges these gaps by accelerating the ability of radiography professional to grow essential knowledge base to influence policy and professionalism. Our approach is to empower Radiography practitioner in areas of research, entrepreneurship and advance practice through a short training course.</p>
                <p>Follow us to get an update on emerging course
                        See some recent publications targeted towards radiography development
                </p>
        </div>
</section>
        </div>

<div class="col-md-6">
<section class="preventive-health" id="prevent">
        <div class="container">
                <h3><strong>Preventive Health and Screening</strong></h3>
                <p>Our main approach to this includes:
                        <ol>
                                <li>Building a network of stakeholders with a focus to resolve a specific health issue (Click here to join our network)
                                </li>
                                <li>Attract sponsorship to implement health screening programs as a social venture (Click here to follow our programs and health initiatives.</li>
                        </ol>
                </p>
        </div>
</section>
</div>
</div>
@endsection