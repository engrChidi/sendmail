<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- Script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' type='text/javascript'></script>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js" defer></script>
    <script src="{{ asset('js/main.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="{{ asset('css/font/css/font-awesome.css') }}" rel="stylesheet">
<link rel="shortcut icon" type="image/png" href="http://codespace.com.ng/img/fav.png"/>
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <style>
        .card1 {
            box-shadow: 0 6px 10px 0 rgba(0,0,0,0.2);
            padding: 15px;
        }
          .kxxx{
            width: 1.1em;
            height: 1.1em;
            border: 2px solid red;
            border-radius: 2px;
            background-color: darkblue;
            cursor: pointer;
        }
        .pppx{
      scrollbar-color: red yellow;
      overflow:scroll;
    }
    </style>
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md shadow-sm pt-3 pb-3">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    <strong>grayscale</strong> International<br>
                    Improving Health Outcome
                </a>
                {{-- <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}"> --}}
                    {{-- <i class="fa fa-bars"></i>
                </button> --> --}}

                <!--{{-- <div class="collapse navbar-collapse" id="navbarSupportedContent"> --}}-->
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav search ml-1 mr-auto">
                        <form action="{{ route('post.index') }}" method="GET" role="search">

                            <div class="input-group ml-3 mt-2">
                                <input type="text" class="form-control" name="term" placeholder="Search posts"
                                    id="term">
                                <span class="input-group-btn">
                                    <button class="btn px-0 pl-1" type="submit" title="Search projects">
                                        <span class="fa fa-search"></span>
                                    </button>
                                </span>
                                {{-- <a href="{{ route('post.index') }}" class="">
                                    <span class="input-group-btn">
                                        <button class="btn" type="button" title="Refresh page">
                                            <span class="fa fa-refresh"></span>
                                        </button>
                                    </span>
                                </a> --}}
                            </div>
                        </form>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <div class="mobile">
                    <div class="dropdown">
                                    <button class="btn btn-default" type="button" data-toggle="dropdown"><i class="fa fa-bars text-dark"></i></button>
                                    <ul class="dropdown-menu mt-1">
                                      <li><a tabindex="-1" href="/" class="text-dark text-decoration-none">Home</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li class="dropdown-submenu dropleft">
                                            <a class="test text-dark text-decoration-none" tabindex="-1" href="#"><i class="fa fa-caret-left text-dark"></i>MasterClass</a>
                                            <ul class="dropdown-menu menu2">
                                                <li><a tabindex="-1" href="/homy" class="text-dark text-decoration-none">About MasterClass</a></li>
                                               <div class="dropdown-divider"></div> 
                                               <li><a tabindex="-1" href="/leader" class="text-dark text-decoration-none">Professional</a></li>
                                                <div class="dropdown-divider"></div>
                                                <li><a tabindex="-1" href="/entrep" class="text-dark text-decoration-none">Entreprenuership</a></li>
                                                <div class="dropdown-divider"></div>
                                                <li><a tabindex="-1" href="/academic" class="text-dark text-decoration-none">Academic</a></li>
                                                <div class="dropdown-divider"></div>
                                                <li><a tabindex="-1" href="/trainingreg" class="text-dark text-decoration-none">SignUp</a></li>
                                            </ul>
                                        </li>
                                                                                <div class="dropdown-divider"></div>
                                      <li><a tabindex="-1" href="/#update" class="text-dark text-decoration-none">Update</a></li>
                                      <div class="dropdown-divider"></div>
                                      <li><a tabindex="-1" href="/about" class="text-dark text-decoration-none">About</a></li>
                                      <div class="dropdown-divider"></div>
                                      <li class="dropdown-submenu dropleft">
                                        <a class="test text-dark text-decoration-none" tabindex="-1" href="#"><i class="fa fa-caret-left text-dark"></i>Services</a>
                                        <ul class="dropdown-menu menu2">
                                          <li><a tabindex="-1" href="/training" class="text-dark text-decoration-none">Training and Capacity Development</a></li>
                                          <div class="dropdown-divider"></div>
                                          <li><a tabindex="-1" href="/health" class="text-dark text-decoration-none">Health and Related Consulting Services</a></li>
                                          <div class="dropdown-divider"></div>
                                          <li><a tabindex="-1" href="/research" class="text-dark text-decoration-none">Market Access and Outcome Research</a></li>
                                          <div class="dropdown-divider"></div>
                                          <li><a tabindex="-1" href="/screen" class="text-dark text-decoration-none">Program Management and Advisory Service</a></li>
                                        </ul>
                                      </li>
                                      @guest

                            @else
                            <div class="dropdown-divider"></div>
                            <li class="dropdown-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="/home">
                                        Dashboard
                                    </a>
                                    <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                        style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                            @endguest
                                    </ul>
                                  </div>
                      </div>
                    </div>
                    <ul class="navbar-nav ml-auto desktop">

                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#masterclass" id="navbarDropdown2"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>MasterClass</a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown2">
                               <a class="dropdown-item" href="/homy">About MasterClass</a> 
                               <a class="dropdown-item" href="/entrep">Entreprenuership</a>
                                <a class="dropdown-item" href="/academic">Academic</a>
                                <a class="dropdown-item" href="/leader">Professional</a>
                                <a class="dropdown-item" href="/trainingreg">Signup</a>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="/#update">Update</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/about">About</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="/#services" id="navbarDropdown"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>Services</a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/training">Training and Capacity Development</a>
                                <a class="dropdown-item" href="/health">Health and Related Consulting Services</a>
                                <a class="dropdown-item" href="/research">Market Access and Outcome Research</a>
                                <a class="dropdown-item" href="/screen">Program Management and Advisory Service</a>
                            </div>
                        </li>



                        <!-- Authentication Links -->
                        @guest

                        @else
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/home">
                                    Dashboard
                                </a>
                                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                    style="display: none;">
                                    @csrf
                                </form>
                            </div>
                        </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="">
            @include('inc.message')
            @yield('content')
        </main>
       
        <footer class="footer1 pt-5 pb-5">
            <div class="container">
                <div class="row">


                    <div class="col-md-6 col-md-offset-3">
                        <h4>Our Contact Information</h4>
                        <p>
                            Phone: +2347083464038 (Call hours 8-5pm)<br>
                            Location: Lagos, Nigeria.<br>
                            Email: support@grayscaleintl.com
                        </p>
                    </div>

  </div>
                </div>

        </footer>
        <footer class="footer2">
            <strong> &copy; {{ date('Y') }} Grayscale Intl || <a href="/policy" class="text-decoration-none">Our
                    Policy</a></strong>
        </footer>
    </div>
    <script>
    
    $(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});

$(".panel-heading").parent('.panel').hover(
  function() {
    $(this).children('.collapse').collapse('show');
  }, function() {
    $(this).children('.collapse').collapse('hide');
  }
);
    </script>
      <script>
    $(document).ready(function(){
        $("#xxx3").show();
        $("#xxx2").hide();
        $("#xxx1").hide();
        $("#xxxb").click(function(){
            $("#xxx1").show();
            $("#xxx2").show("slow");
            $("#xxx3").hide();
            $("#xxxb").hide();
        });
        $("#xxx3b").click(function(){
            $("#xxx2").hide();
            $("#xxx1").show("slow");
            $("#xxx3").hide("slow");
        });
    });
    </script>
</body>

</html>
