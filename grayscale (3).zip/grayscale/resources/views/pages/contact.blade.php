<!-- Success message -->
@if (Session::has('success'))
<div class="alert alert-success">
    {{ Session::get('success') }}
</div>
@endif
<h3>Contact Us</h3>
</div>
<div class="modal-body pr-4 pl-4">
<div class="action-sheet-content">
<form method="POST" action="{{ route('contactUsForm')}}">
    @csrf

    <div class="form-group">
        <div class="row">
            <div class="col-md-6">
                <input type="text" placeholder="Name"
                    class="form-control {{ $errors->has('name') ? 'error' : '' }}"
                    name="name" id="name">
                <!-- Error -->
                @if ($errors->has('name'))
                    <div class="error">
                        {{ $errors->first('name') }}
                    </div>
                @endif
            </div>
            <div class="col-md-6 mob">
                <input type="text" placeholder="Email"
                    class="form-control {{ $errors->has('email') ? 'error' : '' }}"
                    name="email" id="email">
                @if ($errors->has('email'))
                    <div class="error">
                        {{ $errors->first('email') }}
                    </div>
                @endif
            </div>
        </div>
    </div><br>
    <div class="form-group">
        <div class="row">
            <input type="text" placeholder="Subject"
                class="form-control {{ $errors->has('subject') ? 'error' : '' }}"
                name="subject" id="subject">
            @if ($errors->has('subject'))
                <div class="error">
                    {{ $errors->first('subject') }}
                </div>
            @endif
        </div>
    </div><br>
    <div class="form-group">
        <div class="row">
            <textarea name="message" id="" placeholder="Message" cols="30" rows="10"
                class="form-control {{ $errors->has('message') ? 'error' : '' }}"
                name="message" id="message"></textarea>
            @if ($errors->has('message'))
                <div class="error">
                    {{ $errors->first('message') }}
                </div>
            @endif
        </div>
    </div><br>
    <input type="submit" name="send" class="btn btn-lg contact-btn" value="Send">
</form>
