@extends('layouts.app')

@section('content')
<div class="container admin">
<h1>{{$title}}</h1>
<p>Welcome to the Admin Page, Only Admin(s) are allowed here, Please visit the <a href="/post">Blog</a> If you are just a User</p>

<ul class="list-group list-group-flush">
    @guest
    <li class="list-group-item">
        <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
    </li>
    @else
    <p style="font-size: 24px;">
        Welcome Back<a href="#" v-pre>
        {{ Auth::user()->name }}! <span class="caret"></span>
    </a>
    </p>

    <li class="list-group-item">
        <a class="nav-link" href="/home">
            Dashboard
        </a>
    </li>
    <li class="list-group-item">
        <a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
            {{ __('Logout') }}
        </a>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
    </li>
    @endguest
</ul>
</div>

@endsection