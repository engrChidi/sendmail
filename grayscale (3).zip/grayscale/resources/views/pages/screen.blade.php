@extends('layouts.app')

@section('content')
{{-- <div class="screen-header">
        <div class="container">
                <div class="row">

                </div>
        </div>
</div> --}}

<div class="icon-bar">
    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
    <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
    <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
</div>
<section class="about" id="about">
        <div class="container">
                <h3><strong>Program Management and Advisory Service</strong></h3><br>
                <div class="row">
                        <div class="col-md-12">
                        <p>Our main approach to this includes:
                        <ol>
                                <li>Building a network of stakeholders with a focus to resolve a specific health issue (Click here to join our network)
                                </li>
                                <li>Attract sponsorship to implement health screening programs as a social venture (Click here to follow our programs and health initiatives.</li>
                        </ol>
                </p>
                        </div>
                </div>
                <br>
        </div>
</section>

</div>
@endsection
