@extends('layouts.app')

@section('content')
<div class="icon-bar">
    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
    <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
    <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
</div>
    <div class="services">
        <h2>Services</h2>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card text-align-center mb-5">
                    <div class="card-body">
                        <img src="{{ asset('images/train.jpg') }}" alt="" class="ser-img">
                    </div>
                    <div class="card-footer">
                        <a href="/training" class="text-decoration-none">
                            <h5><strong>Training and Capacity Development</strong></h5>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-align-center mb-3">
                    <div class="card-body">
                        <img src="{{ asset('images/consult.png') }}" alt="" class="ser-img">
                    </div>
                    <div class="card-footer">
                        <a href="/health" class="text-decoration-none">
                            <h5><strong>Health and Related Consultancy Services</strong></h5>
                        </a>
                    </div>
                </div>
            </div>

        </div><br>
        <div class="row">
            <div class="col-md-6">
                <div class="card text-align-center mb-5">
                    <div class="card-body">
                        <img src="{{ asset('images/market.jpg') }}" alt="" class="ser-img">
                    </div>
                    <div class="card-footer">
                        <a href="/research" class="text-decoration-none">
                            <h5><strong>Market Access and Outcome Research</strong></h5>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-align-center mb-5">
                    <div class="card-body">
                        <img src="{{ asset('images/program.png') }}" alt="" class="ser-img">
                    </div>
                    <div class="card-footer">
                        <a href="/screen" class="text-decoration-none">
                            <h5><strong>Program Management and Advisory Service</strong></h5>
                        </a>
                    </div>
                </div>
            </div>

        </div><br>
    </div>
@endsection
