@extends('layouts.kk')

@section('content')
    <header>
        <div class="container">
            <div class="row">
                <div class="hero-text">
                    <p><i class="fa fa-quote-left mb-2"></i>Welcome! At GrayScale International we enable our partners to make evidence-based adjustments to their strategies.<i class="fa fa-quote-right"></i></p>
                </div>
            </div>
        </div>
    </header>
    <div class="icon-bar">
        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
        <a href="https://www.linkedin.com/in/grayscale-international-05abb4212/" class="linkedin"><i class="fa fa-linkedin"></i></a>
        <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
    </div>
    <section class="update" id="update">
        <h2>Updates</h2>
        <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <img src="{{ asset ('images/Lagos.jpg') }}" alt="">
                                </div>
                                <div class="card-footer">
                                    <h1><a href="/event" class="text-decoration-none">Events</a>
                                    </h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <img src="{{ asset ('images/services.jpg') }}" alt="">
                                </div>
                                <div class="card-footer">
                                    <h1><a href="/service" class="text-decoration-none">Services</a>
                                    </h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <img src="{{ asset ('images/report.jpg') }}" alt="">
                                </div>
                                <div class="card-footer">
                                    <h1><a href="/post" class="text-decoration-none">News</a>
                                    </h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <img src="{{ asset ('images/project.jpg') }}" alt="">
                                </div>
                                <div class="card-footer">
                                    <h1><a href="/project" class="text-decoration-none">Projects</a>
                                    </h1>
                                </div>
                            </div>
                        </div>

                </div>
    </section>
@endsection
