<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\training;
use App\Contact;
use App\Surveys;
class PagesController extends Controller
{

    public function index(){
     //   $posts = Post::latest()->limit(3)->get();
        return view('pages.index');
    }
    public function theadmin(Request $request){
        $events = training::all();
        return view('training.admin')->with('events', $events);
    }
    public function themsg(Request $request){
    $events = Contact::all();
    return view('pages.msg')->with('events', $events);
}
 public function surv(Request $request){
        $events = Surveys::all();
        return view('training.viewsurvey')->with('events', $events);
    }
    
    public function about(){
        $title ="The About Page";
        return view('pages.about')->with('title', $title);
    }

  public function mid(){
        $title ="The MasterClass";
        return view('pages.mid')->with('title', $title);
    }
 public function subb(){
        $title ="Subscription";
        return view('layouts.kkv')->with('title', $title);
    }
    public function training(){
        $title ="Training and Capacity Development in Health";
        return view('pages.hom')->with('title', $title);
    }

    public function health(){
        $title ="Health Consultancy Services";
        return view('pages.health')->with('title', $title);
    }

    public function research(){
        $title ="Implementation and Outcome Research";
        return view('pages.research')->with('title', $title);
    }

    public function radio(){
        $title ="Radiography Development";
        return view('pages.radio')->with('title', $title);
    }

    public function screen(){
        $title ="Preventive Health and Screening";
        return view('pages.screen')->with('title', $title);
    }

    public function expert(){
        $title ="Meet Our Experts";
        return view('pages.expert')->with('title', $title);
    }

    public function policy(){
        $title ="Our Policy";
        return view('pages.policy')->with('title', $title);
    }

    public function event(){
        $title ="Events";
        return view('training.hom')->with('title', $title);
    }

    public function news(){
        $title ="News";
        return view('pages.news')->with('title', $title);
    }

    public function project(){
        $title ="Projects";
        return view('pages.project')->with('title', $title);
    }

    public function service(){
        $title ="Services";
        return view('pages.service')->with('title', $title);
    }
    public function cdetails(){
    return view('pages.coursedetails');
}
    public function entrepreneurship(){
    return view('training.entrepreneurship');
}
    public function trainingform(){
    return view('training.training');
}
    public function leadership(){
    return view('pages.leadership');
} public function academic(){
    return view('training.academic');
}
    public function mentors(){
    return view('pages.ourmentors');
}
    public function homy(){
        return view('training.hom');
    }
    public function admin(){
        $title = "Admin Page";
        return view('pages.admin')->with('title', $title);
    }
}
