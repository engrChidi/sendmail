<?php

namespace App\Http\Controllers;
use App\Contact;
use Illuminate\Http\Request;
use App\Http\Requests;
class ContactUsController extends Controller
{
    //
    public function contactUsPost(Request $request)
    {
        Contact::create($request->all());
        return back()->with('success', 'Thanks for contacting us!');

    }
}
