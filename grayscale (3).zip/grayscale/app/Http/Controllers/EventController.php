<?php

namespace App\Http\Controllers;

use App\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class EventController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $events = Event::where([
          ['title', '!=', Null],
          [function ($query) use ($request){
            if (($term = $request->term)){
                $query->orWhere ('title', 'LIKE', '%' . $term . '%') -> get();
            }
          }]
        ])
        ->orderBy('id', 'desc')->get();
        return view('events.index')->with('events', $events);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('events.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this -> validate($request, [
            'title' => 'required',
            'body' => 'required',
            'cover_image' => 'mimes:mp4,ppx,ppt,pptx,pdf,ogv,jpeg,jpg,webm,jpg,png|required|max:1999'
        ]);

        // handle the file upload
        if($request->hasFile('cover_image')){
            // get filename extension
            $fileNameExt = $request->file('cover_image')->getClientOriginalName();
            // get just file name
            $fileName = pathinfo($fileNameExt, PATHINFO_FILENAME);
            // get just extension
            $extension = $request->file('cover_image')->getClientOriginalExtension();
            // filename to store
            $fileNameToStore = $fileName . '_'. time(). '.' . $extension;
            // upload image
            $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
        }
        else{
            $fileNameToStore = 'logo.png';
        };

        $event = new Event;
        $event->title = $request->input('title');
        $event->body = $request->input('body');
        $event->user_id = auth()->user()->id;
        $event->cover_image = $fileNameToStore;
        $event->save();

        return redirect('/event')->with('success', 'Event Created.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Event  $event
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event, $id)
    {
        $event = Event::find($id);
        return view('events.show')->with('event', $event);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Event  $event
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Event $event, $id)
    {
        $event = Event::find($id);
        return view('events.edit')->with('event', $event);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Event  $event
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Event $event, $id)
    {
        $this -> validate($request, [
            'title' => 'required',
            'body' => 'required',
            'cover_image' => 'mimes:mp4,ppx,ppt,pptx,pdf,ogv,jpeg,jpg,webm,jpg,png|required|max:1999'
        ]);

        // handle the file upload
        if($request->hasFile('cover_image')){
            // get filename extension
            $fileNameExt = $request->file('cover_image')->getClientOriginalName();
            // get just file name
            $fileName = pathinfo($fileNameExt, PATHINFO_FILENAME);
            // get just extension
            $extension = $request->file('cover_image')->getClientOriginalExtension();
            // filename to store
            $fileNameToStore = $fileName . '_'. time(). '.' . $extension;
            // upload image
            $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
        };


        $event = Event::find($id);
        $event->title = $request->input('title');
        $event->body = $request->input('body');
        if($request->hasFile('cover_image')){
            $event->cover_image = $fileNameToStore;
        }
        $event->save();

        return redirect('/event')->with('success', 'Event updated.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Event  $event
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Event $event, $id)
    {
        $event = Event::find($id);

        if($event->cover_image != 'logo.png'){
            Storage::delete('public/cover_images/'.$event->cover_image);
        }

        $event->delete();

        return redirect('/event')->with('success', 'Event Deleted.');
    }
}
