<?php

namespace App\Http\Controllers;

use App\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactUsFormController extends Controller
{
    public function contactUsForm(Request $request) {

        // Form validation
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email',
            'phone' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
            'country'=>'required',
            'organization'=>'required',
            'city'=>'required',
            'subject'=>'required',
            'message' => 'required'
        ]);
      
        //  Send mail to admin
        Mail::send('mail', array(
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'country' => $request->get('country'),
            'city' => $request->get('city'),
            'organization' => $request->get('organization'),
            'subject' => $request->get('subject'),
            'user_query' => $request->get('message'),
        ), function($message) use ($request){
            $message->from($request->email);
            $message->to('support@grayscaleintl.com', 'Admin')->subject($request->get('subject'));
        });

        return back()->with('success', 'We have received your message and would like to thank you for writing to us.');
    }

    public function contactUs()
    {
        return ;
    }

    public function store(Request $request){
        $con = new Contact;
        $con->first_name = $request->first_name;

        //The $con->first_name is pointing to the db field

        //The $request->first_name is pointing to the field name
    }
}
