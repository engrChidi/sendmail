<?php

namespace App\Http\Controllers;

use App\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProjectController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $projects = Project::where([
          ['title', '!=', Null],
          [function ($query) use ($request){
            if (($term = $request->term)){
                $query->orWhere ('title', 'LIKE', '%' . $term . '%') -> get();
            }
          }]
        ])
        ->orderBy('id', 'desc')->get();
        return view('projects.index')->with('projects', $projects);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('projects.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this -> validate($request, [
            'title' => 'required',
            'body' => 'required',
            'cover_image' => 'mimes:mp4,ppx,ppt,pptx,pdf,ogv,jpeg,jpg,webm,jpg,png|required|max:1999'
        ]);

        // handle the file upload
        if($request->hasFile('cover_image')){
            // get filename extension
            $fileNameExt = $request->file('cover_image')->getClientOriginalName();
            // get just file name
            $fileName = pathinfo($fileNameExt, PATHINFO_FILENAME);
            // get just extension
            $extension = $request->file('cover_image')->getClientOriginalExtension();
            // filename to store
            $fileNameToStore = $fileName . '_'. time(). '.' . $extension;
            // upload image
            $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
        }
        else{
            $fileNameToStore = 'logo.png';
        };

        $project = new Project;
        $project->title = $request->input('title');
        $project->body = $request->input('body');
        $project->user_id = auth()->user()->id;
        $project->cover_image = $fileNameToStore;
        $project->save();

        return redirect('/project')->with('success', 'Project Created.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Project  $project
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $project = Project::find($id);
        return view('projects.show')->with('project', $project);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Project  $project
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $project = Project::find($id);
        return view('projects.edit')->with('project', $project);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Project  $project
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Project $project, $id)
    {
        $this -> validate($request, [
            'title' => 'required',
            'body' => 'required',
            'cover_image' => 'mimes:mp4,ppx,ppt,pptx,pdf,ogv,jpeg,jpg,webm,jpg,png|required|max:1999'
        ]);

        // handle the file upload
        if($request->hasFile('cover_image')){
            // get filename extension
            $fileNameExt = $request->file('cover_image')->getClientOriginalName();
            // get just file name
            $fileName = pathinfo($fileNameExt, PATHINFO_FILENAME);
            // get just extension
            $extension = $request->file('cover_image')->getClientOriginalExtension();
            // filename to store
            $fileNameToStore = $fileName . '_'. time(). '.' . $extension;
            // upload image
            $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
        };


        $project = Project::find($id);
        $project->title = $request->input('title');
        $project->body = $request->input('body');
        if($request->hasFile('cover_image')){
            $project->cover_image = $fileNameToStore;
        }
        $project->save();

        return redirect('/project')->with('success', 'Project updated.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Project $project, $id)
    {
        $project = Project::find($id);

        if($project->cover_image != 'logo.png'){
            Storage::delete('public/cover_images/'.$project->cover_image);
        }

        $project->delete();

        return redirect('/project')->with('success', 'Project Deleted.');
    }
}
