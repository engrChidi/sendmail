<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Surveys extends Model
{
    protected $fillable = [

        'sex', 'country', 'age', 'qualification', 'academic', 'years', 'do', 'start', 'equipment', 'capital','current',  'bizneed', 'cusneed', 'next', 'staff', 'experience', 'strategic'
    ];

    public function setEquipmentAttribute($value)
    {
        $this->attributes['equipment'] = json_encode($value);
    }

    public function getEquipmentAttribute($value)
    {
        return $this->attributes['equipment'] = json_decode($value);
    }
    public function setBizneedAttribute($value)
    {
        $this->attributes['bizneed'] = json_encode($value);
    }
    public function getBizneedAttribute($value)
    {
        return $this->attributes['bizneed'] = json_decode($value);
    }
    public function getCusneedAttribute($value)
    {
        return $this->attributes['cusneed'] = json_decode($value);
    }
    public function setCusneedAttribute($value)
    {
        return $this->attributes['cusneed'] = json_encode($value);
    }
}
