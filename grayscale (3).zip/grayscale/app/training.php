<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class training extends Model
{
    //
}
