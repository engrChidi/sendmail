//Sliders//
$('.box-slider-content').slick({
	centerMode: true,
   infinite: true,
   slidesToShow: 3,
   dots: false,
   appendDots:jQuery(".box-dots"),
   autoplay: false,
   responsive: [
   {
	 breakpoint: 768,
	 settings: {
	   slidesToShow: 1
	 }
   }
  ]
 });

 function openNav() {
	document.getElementById("mySidenav").style.width = "100%";
  }
  
  function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
  }

let burger = document.getElementById('burger'),
	 nav    = document.getElementById('main-nav'),
	 slowmo = document.getElementById('slowmo');

burger.addEventListener('click', function(e){
	this.classList.toggle('is-open');
	nav.classList.toggle('is-open');
});

slowmo.addEventListener('click', function(e){
	this.classList.toggle('is-slowmo');
});

/* Onload demo - dirty timeout */
let clickEvent = new Event('click');

window.addEventListener('load', function(e) {
	slowmo.dispatchEvent(clickEvent);
	burger.dispatchEvent(clickEvent);
	
	setTimeout(function(){
		burger.dispatchEvent(clickEvent);
		
		setTimeout(function(){
			slowmo.dispatchEvent(clickEvent);
		}, 3500);
	}, 5500);
});
