<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSurveysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('survey', function (Blueprint $table) {
            $table->id();
            $table->string('sex');
            $table->string('country');
            $table->string('age');
            $table->string('qualification');
            $table->string('academic');
            $table->string('years');
            $table->string('do');
            $table->string('start');
            $table->longText('equipment');
            $table->string('capital');
            $table->string('current');
            $table->string('bizneed');
            $table->string('cusneed');
            $table->string('next');
            $table->string('staff');
            $table->string('experience');
            $table->string('strategic');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('surveys');
    }
}
