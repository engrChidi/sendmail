<?php $__env->startSection('content'); ?>


<section class="about" id="about">
        <div class="container">
                <h3><strong>Market Access and Outcome Research</strong></h3><br>
                <div class="row">
                        <div class="col-md-6">
                                <img src="<?php echo e(asset('images/research.jpeg')); ?>" alt="research" class="research-img">
                        </div>
                        <div class="col-md-6">
                        <p>GSI is positioned to drive evidence base improvement that promotes real health outcomes. Broadly we assist our partners and collaborators to:
                        <ol>
                                <li>Perform Field data management from Countries in Africa</li>
                                <li>Conduct implementation research related to product and programs effectiveness in the African context. Our outputs readily support market access for these products and services.</li>
                                <li>Coordinate a network of associates for multicountry implementation research based on the requirement of our customer/partners.</li>
                                <li>Drive the devolution of evidence-based into routine service offering (level 1 and level 2 translational research implementation).</li>
                        </ol>
                </p>
                        </div>
                </div>
                <br>
        </div>
</section>

<section class="contact" id="">
        <div class="container">
                <h3><strong>Contact Us</strong></h3><br>
                <!--<div class="row add mb-3">-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-envelope"></i><br>-->
                <!--                <var>grayscale email</var>-->
                <!--        </div>-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-phone"></i><br>-->
                <!--                <var>+2348063280360</var>-->
                <!--        </div>-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-map-marker"></i><br>-->
                <!--                <var>Grayscale International Lagos, Nigeria</var>-->
                <!--        </div>-->
                <!--</div><br>-->
                <div class="row">
                        <div class="col-md-6">
                                <input type="text" placeholder="Name" class="form-control">
                        </div>
                        <div class="col-md-6">
                                <input type="text" placeholder="Email" class="form-control">
                        </div>
                </div><br>
                <div class="row">
                <div class="col-md-6">
                        <input type="text" placeholder="Phone" class="form-control">
                </div>
                <div class="col-md-6">
                        <input type="text" placeholder="Organization" class="form-control">
                </div>
        </div><br>
        <div class="row">
                <div class="col-md-6">
                        <input type="text" placeholder="Country/Region" class="form-control">
                </div>
                <div class="col-md-6">
                        <input type="text" placeholder="City" class="form-control">
                </div>
        </div><br>
                <div class="row">
                        <input type="text" placeholder="Subject" class="form-control">
                </div><br>
                <div class="row">
                        <textarea name="message" id="" placeholder="Message" cols="30" rows="10" class="form-control"></textarea>
                </div><br>
                <input type="submit" class="btn btn-lg contact-btn" value="Send">
        </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/research.blade.php ENDPATH**/ ?>