

<?php $__env->startSection('content'); ?>


<section class="about" id="about">
        <div class="container">
                <h3><strong>Meet Our Experts</strong></h3><br>
                <div class="row">
                        <div class="col-md-5">
                                <img src="<?php echo e(asset('images/Ekpo.jpg')); ?>" alt="" class="ser-img">
                        </div>
                        <div class="col-md-7 mobl">
                                <h4><strong>Ernest Ekpo. PhD.</strong></h4>
                                <p>Dr Ernest Ekpo is a Medical Imaging expert and Academic. With over 50 papers in high ranking peer-reviewed journals and multiple awards including Editor’s choice papers, best conference presentations, Publons top peer reviewer medals, Sydney Accelerator Research Prize, and Harvard Mobility award, he is regarded as a leader in Medical Imaging. Dr Ekpo is an external PhD examiner and reviewer for major funding bodies and international journals. He currently sits on the Editorial Boards of Medical Imaging and Breast Cancer Journals as well as the Faculty Board of Medicine and Health and the Discipline of Medical Imaging Sciences leadership team at the University of Sydney. Dr Ekpo was recently appointed Director of the Medical Imaging Optimisation and Perception Group (MIOPeG) for 2021- 2020 and is a key member of the Breast Reader Assessment Strategy (BREAST), Sydney Catalyst Translational Cancer Research, Cancer Research Network, Sydney Vital Translational Cancer Research, and Primary Care Collaborative Cancer Clinical Trials Group (PC4).</p>
                        </div>
                </div>
                <div class="row mt-5 reverse">
                        <div class="col-md-7 mobl">
                                <h4><strong>Felix O Erondu PhD.</strong></h4>
                                <p>Prof. Felix O. Erondu is a practising Medical Imaging Consultant, entrepreneur, philanthropist, and accomplished University don. He currently holds a Professorial Chair at the Gregory University Uturu, Nigeria. He is the President/ CEO of Image Diagnostics Inc and a range of affiliate companies with combine net value at $0.5 billion, which he grew from scratch over 20 years. Image Diagnostics currently provide medical diagnostic services to about two hundred thousand patients annually, delivered by close to two hundred employees. Prof. Erondu is an astute Health Administrator, obtain his MBA qualification from the Walden University, in the USA, and a  Fellow of The Institute of Management Consultants.</p>
                        </div>
                        <div class="col-md-5">
                                <img src="<?php echo e(asset('images/Felix.jpg')); ?>" alt="" class="ser-img">
                        </div>
                </div>
                <div class="row mt-5">
                        <div class="col-md-5">
                                <img src="<?php echo e(asset('images/Eyo.png')); ?>" alt="" class="ser-img">
                        </div>
                        <div class="col-md-7 mobl">
                                <h4><strong>Eyo Akpan (M.Sc.)</strong></h4>
                                <p>Eyo is a Radiographer with Special Interest in Medical Ultrasound. He has a wide range of experience in the application of radiography spanning the extremes; He holds certificates in five Industrial Radiography (Non-destructive testing NDT) techniques. In the corporate and healthcare business development, Eyo has implemented turnkey health programs across more than seven countries in Africa, managing a portfolio exceeding 3.0 million dollars. In his recent role, he coordinated capacity development programs for about one thousand five hundred health workers on the use of the portable ultrasound for early detection of pregnancy complication and to screen nearly 1 million pregnant mothers over the three years. Eyo has a research and development interest in the use of medical imaging to transform public health outcomes, especially in maternal health, preventive oncology and preventive cardiology.</p>
                        </div>
                </div>
                <br>
        </div>
</section>

<section class="contact" id="">
        <div class="container">
                <h3><strong>Contact Us</strong></h3><br>
                <!--<div class="row add mb-3">-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-envelope"></i><br>-->
                <!--                <var>grayscale email</var>-->
                <!--        </div>-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-phone"></i><br>-->
                <!--                <var>+2348063280360</var>-->
                <!--        </div>-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-map-marker"></i><br>-->
                <!--                <var>Grayscale International Lagos, Nigeria</var>-->
                <!--        </div>-->
                <!--</div><br>-->
                <div class="row">
                        <div class="col-md-6">
                                <input type="text" placeholder="Name" class="form-control">
                        </div>
                        <div class="col-md-6">
                                <input type="text" placeholder="Email" class="form-control">
                        </div>
                </div><br>
                <div class="row">
                <div class="col-md-6">
                        <input type="text" placeholder="Phone" class="form-control">
                </div>
                <div class="col-md-6">
                        <input type="text" placeholder="Organization" class="form-control">
                </div>
        </div><br>
        <div class="row">
                <div class="col-md-6">
                        <input type="text" placeholder="Country/Region" class="form-control">
                </div>
                <div class="col-md-6">
                        <input type="text" placeholder="City" class="form-control">
                </div>
        </div><br>
                <div class="row">
                        <input type="text" placeholder="Subject" class="form-control">
                </div><br>
                <div class="row">
                        <textarea name="message" id="" placeholder="Message" cols="30" rows="10" class="form-control"></textarea>
                </div><br>
                <input type="submit" class="btn btn-lg contact-btn" value="Send">
        </div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/expert.blade.php ENDPATH**/ ?>