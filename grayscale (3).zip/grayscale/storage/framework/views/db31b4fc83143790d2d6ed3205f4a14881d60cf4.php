

<?php $__env->startSection('content'); ?>
    <script>
        function printDiv() {
            var divContents = document.getElementById("GFG").innerHTML;
            var a = window.open('', '', 'height=900, width=1200');
            a.document.write('<html>');
            a.document.write('<body > <h1>List of Registrants <br>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }

    </script>

    <div class="container">
        <a href="/" class="btn btn-dark text-decoration-none">Go Home</a>   <a href="/themsg" class="btn btn-warning text-decoration-none">Read Msg</a>
        <a href="/surv" class="btn btn-success text-decoration-none">Survey</a> <h1 align="center">List of Registrants</h1>
        <div class="row">
            <div class="col-md-8 col-md-offset-2 card1" style="margin: auto" id="all">
                <?php if(count($events) > 0): ?>
                    <div>
                        <textarea rows="5" class="form-control" id="content">
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($event->Email); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </textarea>
                    </div>
                <table width="100%"><tr>
                        <td align="left">
                            <button onclick="" id="copyID" class="btn btn-primary btn-sm"><i class="fa fa-angle-up"></i> Copy Emails</button>
                        </td>

                        <td align="center"><br>
                            <button onclick="printDiv()" id="printa"  class="btn btn-success btn-sm"><i class="fa fa-print"></i> Print List</button> </td>
                    </tr></table><div class="card1"  id="GFG" align="center">
                <table class="table table-hover table-striped table-bordered" align="center"  id="GFG">
                    <tr>
                        <td>
                            NAME
                        </td>
                        <td>
                            COURSE
                        </td>
                        <td>
                            EMAIL
                        </td>
                        <td>
                            COUNTRY
                        </td>
                        <td>
                            PHONE
                        </td>
                        <td>
                            GENDER
                        </td>
                    </tr>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $events): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($events->Name); ?></td>
                            <td><?php echo e($events->Course); ?></td>
                            <td><?php echo e($events->Email); ?></td>
                            <td><?php echo e($events->State); ?></td>
                            <td><?php echo e($events->Phone); ?></td>
                            <td><?php echo e($events->Gender); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php else: ?>
<h3 align="center">Sorry: no registrant yet.</h3>
                <?php endif; ?>
                </div>
            </div>
        </div>

        <script type="text/javascript">
            var button = document.getElementById("copyID"),
                    input = document.getElementById("content");

            button.addEventListener("click", function(event) {
                event.preventDefault();
                input.select();
                document.execCommand("copy");
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/training/admin.blade.php ENDPATH**/ ?>