

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12"><br>
            <h2>Academic Mentorship Program (AMP)</h2>
            <a href="/mid" class="btn btn-outline-danger">Click here to Sign-up for this Program
                </a>
                </div> <div>Program leader:  <b><a href="#"> Ernest Ekpo. PhD</a></b>
            </div>

        </div>
            <div class="row">
            <div class="col-md-6">
                <div class="card" style="width:100%; background-color: #efefef">
                    <img class="card-img-top"  src="http://codespace.com.ng/img/acad.png" alt="Card image">
                    <div class="card-body">
                        <p class="card-text">
                This academic mentorship program is strategic in design to help academics, intending academics,
                and professionals interested in research and funding to develop competencies that are crucial to
                achieving success in academia and research. In a number of sessions, this master class will equip participants
                with skills to create a program of research and to effectively communicate research findings in high impact
                peer-reviewed journals, attract research funding and industry partnerships, use effective teaching pedagogies
                and technologies, and develop an excellent track record of academic leadership.</p>
                        </div></div>
</div>
            <div class="col-md-6" style="padding-left: 5px">
               <b>Aim:</b> Promoting teaching, research, and academic leadership development in resource-constrained settings.
                <p><b>Objective:</b> To mentor academics to strategically  develop track record of teaching, research, leadership and engagement.
                </p>
                <b>Target audience:</b> Lecturers in imaging or Radiotherapy, radiographers and imaging professionals in research, clinical imaging professionals with interest in research and publishing

               <p><b>Structure:</b> The 3-month mentorship program has e-mentorship sessions, didactic and practical, and self-paced development plan.
                </p>
               <b> Mode of delivery:</b> Online

               <p><b>Topics area covered:</b>
                   <ul>
                    <li>Research program development;</li>
                    <li>Research methods and data analysis;</li>
                    <li>Academic writing (original papers, narrative and systematic reviews and meta-analysis, revision of submitted papers, coping with rejection);
                        </li>
                    <li>Peer-review of scientific papers and grant applications;</li>
                    <li>Developing grant applications and targeting strategic funding opportunities;</li>
                    <li>Developing research collaboration, networks, and Industry partnership;</li>
                    <li>Novel teaching pedagogies and technologies;</li>
                    <li>Strategic positioning for leadership and success in academia;</li>
                    <li>Professional and personal development assessment and planning</li>
                </ul>
 <a href="/mid" class="btn btn-outline-danger">Click here to Sign-up for this Program
                </a>
                </p>
            </div >
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/training/academic.blade.php ENDPATH**/ ?>