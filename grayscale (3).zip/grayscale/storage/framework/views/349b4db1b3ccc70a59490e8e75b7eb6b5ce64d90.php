

<?php $__env->startSection('content'); ?>
    

    <section class="policy" id="about">
        <div class="container">
            <h3><strong>Our Policy</strong></h3><br>
            <div class="row">
                <p>As recipients of US government funding, the US government policy prohibits Grayscale, its employees,
                    consultants, subrecipients, and subcontractors from:
                <ol>
                    <li>
                        Engaging in severe forms of trafficking in persons while working on a program or project sponsored
                        by the US government. This means:
                        <ul>
                            <li>
                                Sex trafficking in which a commercial sex act is induced by force, fraud, or coercion, or in
                                which the person induced to perform the act is under 18 years of age; or
                            </li>
                            <li>
                                Recruiting, transporting, or harboring a person for labor or services through the use of
                                force, fraud, or coercion for the purposes of involuntary servitude, peonage, debt bondage,
                                or slavery.
                            </li>
                        </ul>
                    </li>
                    <li>
                        Procuring commercial sex acts during the contract period.</li>
                    <li>
                        Using forced labor in performing the contract.</li>
                    <li>
                        Destroying, concealing, confiscating, or otherwise denying access by an employee to the employee’s
                        identity papers or immigration documents, such as passports, identification cards, or drivers’
                        licenses</li>
                    <li>
                        Use of deceptive or unlawful employment strategies, including:
                        <ul>
                            <li>
                                Failing to disclose to the employee in a format and language that he or she understands:
                                <ol>
                                    <li>
                                        Terms and conditions of employment, including wages and fringe benefits.</li>
                                    <li>
                                        The location of work.</li>
                                    <li>
                                        The living conditions, housing, and associated costs.</li>
                                    <li>
                                        Any significant costs to be charged.</li>
                                    <li>
                                        If applicable, the hazardous nature of the work.</li>
                                </ol>
                            </li>
                            <li>
                                Using recruiters who do not comply with local labor laws of the country in which the
                                recruiting takes place.</li>
                        </ul>
                    </li>
                    <li>
                        Charging employees recruitment fees</li>
                </ol>
                </p>
                <p>
                All GrayScale personnel, suppliers, and supplier personnel are required to report any suspected
                trafficking-related activity or violation of this policy to GrayScale.</p>
                <p>
                GrayScale employees are strongly encouraged to report any violation of this policy directly to the GrayScale
                chief financial officer/vice president (CFO/VP) and/or chief human resources and administrative officer
                (CHRAO) as both an effective and expeditious means of addressing the required reporting of potential
                violations. In addition and in the case of suppliers/contractors and their personnel, as well as GrayScale
                employees, reports may be made to any GrayScale supervisor, senior country office management (which includes
                country directors or project chief of party), or headquarters human resources representative. Any GrayScale
                supervisor, member of senior country office management, or headquarters human resources representative who
                receives such a report is required to immediately forward the report to the GrayScale CFO/VP and CHRAO.
                Supplier personnel who believe they or others have been subjected to prohibited trafficking-related
                activities may report the activity as outlined above. Reports may be also be made via GrayScale’s anonymous
                compliance hotline online at <strong>www.grayscaleintl.com</strong>, by email to <strong>support@grayscaleintl.com</strong>, or by phone:</p>

                US: (1-866) 921-6714<br>
                Philippines: 00-800-2002-0033<br>
                India: 0008001007980<br>
                Indonesia PT Indosat: 0018030208158<br>
                Indonesia PT Telkom: 0078030208158<br>

                <p>For all other countries, contact the international operator, ask to place a collect call to
                001-604-922-5953, then ask for a whistleblower agent.</p>

                <p>Human resources will investigate all reports of prohibited trafficking-related activity or violations of
                this policy and take appropriate action. The Office of the CFO/VP will make all required notifications to
                government agencies, as more fully set out in this compliance plan.</p>

                <p>GrayScale strictly prohibits retaliation against any GrayScale employee who reports prohibited
                trafficking-related activity or other violations of this policy, or who cooperates with any internal or
                government investigations of such reports. Employees may do so without fear of reprisal. GrayScale personnel
                who engage in any form of retaliation against those who report prohibited trafficking-related activities or
                other violations of this policy are subject to disciplinary action, up to and including termination of
                employment with GrayScale.</p>
            </div>
            <br>
        </div>
    </section>

    <section class="contact" id="">
        <div class="container">
            <h3><strong>Contact Us</strong></h3><br>
            <div class="row add mb-3">
                <div class="col-md-4">
                    <i class="fa fa-envelope"></i><br>
                    <var>grayscale email</var>
                </div>
                <div class="col-md-4">
                    <i class="fa fa-phone"></i><br>
                    <var>+2348063280360</var>
                </div>
                <div class="col-md-4">
                    <i class="fa fa-map-marker"></i><br>
                    <var>Grayscale International Lagos, Nigeria</var>
                </div>
            </div><br>
            <div class="row">
                <div class="col-md-6">
                    <input type="text" placeholder="Name" class="form-control">
                </div>
                <div class="col-md-6">
                    <input type="text" placeholder="Email" class="form-control">
                </div>
            </div><br>
            <div class="row">
                <input type="text" placeholder="Subject" class="form-control">
            </div><br>
            <div class="row">
                <textarea name="message" id="" placeholder="Message" cols="30" rows="10" class="form-control"></textarea>
            </div><br>
            <input type="submit" class="btn btn-lg contact-btn" value="Send">
        </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/policy.blade.php ENDPATH**/ ?>