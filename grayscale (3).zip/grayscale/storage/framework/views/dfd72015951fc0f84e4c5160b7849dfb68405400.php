

<?php $__env->startSection('content'); ?>
<div class="radio-header">
        <div class="container">
                <div class="row">

                </div>
        </div>
</div>

<section class="about" id="about">
        <div class="container">
                <h3><strong>Radiography Development</strong></h3><br>
                <div class="row">
                        <div class="col-md-12">
                        <p>Medical imaging and radiography in Africa are still developing. Gaps in academic radiography translate into weak professional practice and professionalism in the health sector. The emergence of Artificial intelligence AI, public health radiography and consultant practice (advance practice) further challenges radiography development in Africa.</p>
                <p>GSI bridges these gaps by accelerating the ability of radiography professional to grow essential knowledge base to influence policy and professionalism. Our approach is to empower Radiography practitioner in areas of research, entrepreneurship and advance practice through a short training course.</p>
                <p>Follow us to get an update on emerging course
                        See some recent publications targeted towards radiography development
                </p>
                        </div>
                </div>
                <br>
        </div>
</section>

<section class="contact" id="">
        <div class="container">
                <h3><strong>Contact Us</strong></h3><br>
                <div class="row add mb-3">
                        <div class="col-md-4">
                                <i class="fa fa-envelope"></i><br>
                                <var>grayscale email</var>
                        </div>
                        <div class="col-md-4">
                                <i class="fa fa-phone"></i><br>
                                <var>+2348063280360</var>
                        </div>
                        <div class="col-md-4">
                                <i class="fa fa-map-marker"></i><br>
                                <var>Grayscale International Lagos, Nigeria</var>
                        </div>
                </div><br>
                <div class="row">
                        <div class="col-md-6 pr-1">
                                <input type="text" placeholder="Name" class="form-control">
                        </div>
                        <div class="col-md-6 pl-1">
                                <input type="text" placeholder="Email" class="form-control">
                        </div>
                </div><br>
                <div class="row">
                        <input type="text" placeholder="Subject" class="form-control">
                </div><br>
                <div class="row">
                        <textarea name="message" id="" placeholder="Message" cols="30" rows="10" class="form-control"></textarea>
                </div><br>
                <input type="submit" class="btn btn-lg contact-btn" value="Send">
        </div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/radio.blade.php ENDPATH**/ ?>