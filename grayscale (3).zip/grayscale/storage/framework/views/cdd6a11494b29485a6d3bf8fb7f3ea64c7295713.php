

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2" style="margin: auto">
        <br>

                <h3 align="center" style="color: blue">GSi MasterClass Series.</h3> <div align="center">Entrepreneurship in Medical Imaging and Radiation Therapy</div>

                <h4 align="center" style="color: red">Online Survey Questionnaire</h4>
        <hr align="center" style="width: 50%">

       <div class="btn-success" align="center"> <i class="fa fa-thumbs-up fa-2x"></i> &nbsp; Thank You so much for participating in our survey </div>
<p align="center"><br>
        <a href="/" class="btn btn-dark">Back to previous page</a></p>
                <p align="center">    <a href="/entrep" class="btn btn-warning">Register for Entrepreneurship Mentorship Program</a></p>
                <p align="center"><a href="/sub" class="btn btn-primary">Further Enquiry? Contact Us</a> </p>



            </div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/training/done.blade.php ENDPATH**/ ?>