

<?php $__env->startSection('content'); ?>
<div class="container admin">
<h1><?php echo e($title); ?></h1>
<p>Welcome to the Admin Page, Only Admin(s) are allowed here, Please visit the <a href="/post">Blog</a> If you are just a User</p>

<ul class="list-group list-group-flush">
    <?php if(auth()->guard()->guest()): ?>
    <li class="list-group-item">
        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
    </li>
    <?php else: ?>
    <p style="font-size: 24px;">
        Welcome Back<a href="#" v-pre>
        <?php echo e(Auth::user()->name); ?>! <span class="caret"></span>
    </a>
    </p>

    <li class="list-group-item">
        <a class="nav-link" href="/home">
            Dashboard
        </a>
    </li>
    <li class="list-group-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </li>
    <?php endif; ?>
</ul>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/admin.blade.php ENDPATH**/ ?>