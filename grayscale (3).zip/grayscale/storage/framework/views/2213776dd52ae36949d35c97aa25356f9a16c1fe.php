<?php $__env->startSection('content'); ?>
<header>
        <div class="container">
                <div class="row">

                </div>
        </div>
</header>
<div class="icon-bar">
    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
    <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
    <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
</div>
<div class="about-page">
<section class="about" id="about">
        <div class="container">
                <h3><strong>About Us</strong></h3><br>
                <div class="row">
                        <div class="col-md-4 mb-4">
                                <div class="gray">
                                        <strong>grayscale international</strong><br>
                    <span class="imp">Improving Health Outcome</span>
                                </div>
                        </div>
                        <div class="col-md-8">
                                <p>GrayScale International (GSi) is a Nigerian Based Limited Liability company (RC 1718641) located in Lagos. GSi is a response to the gaps created by the ailing health system in low-to-mid income countries, especially in Africa to help our partners, customers and collaborators make an evidence-based adjustment to their strategies for improved outcomes. GSi blends both for-the-profit and social enterprise strategy to strengthen health systems, utilise loco-regional evidence-base to improve service and operational efficiency or effectiveness of a specific health program, drive the integration of innovative and sustainable products and services which result to the attainment of our partner-specific health outcomes. We do so by delivering on training and capacity development, offering consultancy services, carrying out Market access or outcome evaluation, and program management services to our partners and stakeholders priorities.
Our core values include integrity, inclusiveness, team-winning, people's leadership and LEAN operations. GSi empowers communities by helping her partners and collaborators to deliver results in moments that matters regardless of prevailing uncertainties.

Using our contact, we look forward to hear from and partner with you.

                                </p>
                        </div>

                </div><br>
        </div>
</section>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/about.blade.php ENDPATH**/ ?>