<?php $__env->startSection('content'); ?>


<section class="about" id="about">
        <div class="container">
                <h3><strong>Training and Capacity Development</strong></h3><br>
                <div class="row">
                        <div class="col-md-6">
                                <img src="<?php echo e(asset('images/team.jpeg')); ?>" alt="training" class="train-img">
                        </div>
                        <div class="col-md-6">
                        <p>The health and care practice is continually evolving in line with emerging evidence; therefore, health and care professionals are required to continuously improve on their professional development so that members of their communities receive quality healthcare services. This requirement, however basic, is not attainable in many developing nations due to the gaps in human resource engineering, i.e. shortage of skill and number of HCW, knowledge gaps, lack of appropriate motivation, lack of specialisation routes, lack of a local mechanism to integrate emerging evidence-based into practice, underfunding of their learning and development.

</p>
                        </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                <p>
                        GSi draws from her experience in training and capacity development and health system strengthening of more than ten African countries to provide our clients with expert services in the following area; content development, training logistics management, course delivery, skill and knowledge evaluation, capacity development for health system strengthening.
We focus primarily on improving the utility and quality of care at primary and secondary healthcare levels. We have the expertise to implement essential components of health system strengthening, change acceleration processes in health, outcome-driven adjustment to skill, operation and functionality improvements.

Submit your request;
                </p>

                        </div>

                </div><br>
                <p>GSi Mentorship Program:
                        <ul>
                                <li>
                                        <a href="#" class="text-decoration-none">Meet our expert </a>
                                </li>
                                <li>
                                        <a href="#" class="text-decoration-none">About the GSi Mentorship Program </a>
                                </li>
                                <li>
                                        <a href="#" class="text-decoration-none"> Sign up </a>
                                </li>
                                <li>
                                        <a href="#" class="text-decoration-none"> Alumni </a>
                                </li>
                        </ul>
                </p>
        </div>
</section>

<section class="contact" id="">
        <div class="container">
                <h3><strong>Contact Us</strong></h3><br>
                <!--<div class="row add mb-3">-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-envelope"></i><br>-->
                <!--                <var>grayscale email</var>-->
                <!--        </div>-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-phone"></i><br>-->
                <!--                <var>+2348063280360</var>-->
                <!--        </div>-->
                <!--        <div class="col-md-4">-->
                <!--                <i class="fa fa-map-marker"></i><br>-->
                <!--                <var>Grayscale International Lagos, Nigeria</var>-->
                <!--        </div>-->
                <!--</div><br>-->
                <div class="row">
                        <div class="col-md-6">
                                <input type="text" placeholder="Name" class="form-control">
                        </div>
                        <div class="col-md-6">
                                <input type="text" placeholder="Email" class="form-control">
                        </div>
                </div><br>
                <div class="row">
                <div class="col-md-6">
                        <input type="text" placeholder="Phone" class="form-control">
                </div>
                <div class="col-md-6">
                        <input type="text" placeholder="Organization" class="form-control">
                </div>
        </div><br>
        <div class="row">
                <div class="col-md-6">
                        <input type="text" placeholder="Country/Region" class="form-control">
                </div>
                <div class="col-md-6">
                        <input type="text" placeholder="City" class="form-control">
                </div>
        </div><br>
                <div class="row">
                        <input type="text" placeholder="Subject" class="form-control">
                </div><br>
                <div class="row">
                        <textarea name="message" id="" placeholder="Message" cols="30" rows="10" class="form-control"></textarea>
                </div><br>
                <input type="submit" class="btn btn-lg contact-btn" value="Send">
        </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/training.blade.php ENDPATH**/ ?>