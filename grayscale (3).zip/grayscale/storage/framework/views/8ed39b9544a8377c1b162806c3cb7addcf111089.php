

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12"><br>
                <h4>Professional Development Mentorship Program (AMP) </h4>

                <div><a href="/mid" class="btn btn-outline-primary">Click here to Sign-up for this Program
                    </a></div><div>Program leader:  <b><a href="#">Eyo Akpan (M.Sc.)</a></b>
                </div>
            </div></div>
        <div class="row">
            <div class="col-md-6">
                <div class="card" style="width:100%; background-color: #efefef; border:none">
                    <img class="card-img-top"  src="http://codespace.com.ng/img/ld.png" alt="grayscale">
                    <div class="card-body">
                        <p class="card-text">
                            This module structure will accentuate the professional development of health professionals. It transfers essential leadership skills to its participants and challenges their aspiration to advance in their practice through expert practice, research, leadership and coaching. Participants should discover the professional progression pathway matched to their unique personal attributes, research interest and loco-regional health needs.
                        </p></div></div>
            </div>
            <div class="col-md-6"  style="padding-left: 5px">
                <b> Aim:</b> To promote professional development in Healthcare especially in the domain of Medical Imaging and Radiation Therapy (MIRT) in resource constraint setting
                <p><b>Objective:</b>
                    Equip MIRT professionals to succeed in their professional quest through self-reinvention and advancing practice

                </p> <b>Target audience:</b>
                MIRT Professionals, other practitioners with interested in or practising an aspect of imaging
                <p><b>Structure</b>
                    The 3-month mentorship program has e-mentorship sessions, didactic, and self-paced development plan
                </p>
                <b>Mode of delivery:</b> Online

                <p> <b>Topics area covered:</b>
                <ul><li>Professional Portfolio in Practice</li>
                    <li>Specialising & Advancing your practice</li>
                    <li>Emerging trends in radiography</li>
                    <li> Building essential leadership skills</li>
                    <li>Personalize (professional) development & consulting</li>

                </ul>
                <a href="/mid" class="btn btn-outline-primary">Click here to Sign-up for this Program
                    </a>
                </p>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/leadership.blade.php ENDPATH**/ ?>