

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12"> <br>  <h3 align="center">Meet Our Expert Trainers</h3></div>

    <div class="col-md-4">
        <div class="card" style="width:100%">
            <img class="card-img-top"  src="http://codespace.com.ng/img/felix.png" alt="grayscale">
            <div class="card-body">
                <h4 class="card-title">Felix O Erondu PhD:
                </h4>
                <p class="card-text">
                    Prof. Felix O. Erondu is a practicing Medical Imaging Consultant and entrepreneur. He currently holds a Professorial Chair at the Gregory University Uturu, Nigeria and MBA qualification from the Walden University, USA. He is a  Fellow of The Institute of Management Consultants.
                    And the President/ CEO of Image Diagnostics Inc.
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card" style="width:100%">
            <img class="card-img-top"  src="http://codespace.com.ng/img/earnest2.jpeg" alt="gray scale international">
            <div class="card-body">
                <h4 class="card-title">Ernest Ekpo. PhD:</h4>
                <p class="card-text">Dr Ernest Ekpo is a Medical Imaging expert With over 50 papers in high ranking peer-reviewed journals. He currently sits on the Editorial Board of Medical Imaging and Breast Cancer Journal as well as the Faculty Board of Medicine and Health and the Discipline of Medical Imaging Sciences leadership team at the University of Sydney.
                </p>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card" style="width:100%">
            <img class="card-img-top"  src="http://codespace.com.ng/img/eyo.png" alt="grayscale">
            <div class="card-body">
                <h4 class="card-title">Eyo Akpan(M.Sc.)</h4>
                <p class="card-text"> Eyo is a vastly knowledgeable Radiographer with certification in different industrial radiography techniques, diagnostic radiography and radiation therapy. Eyo has a diversified skill set in public health, program management, market access, and health technology integration in low-income settings. He serves as an independent consultant to various projects in Africa and currently researching how medical imaging transforms public health outcomes, especially in maternal health, preventive oncology, and preventive cardiology. </p>
            </div>
        </div>
    </div>

</div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/ourmentors.blade.php ENDPATH**/ ?>