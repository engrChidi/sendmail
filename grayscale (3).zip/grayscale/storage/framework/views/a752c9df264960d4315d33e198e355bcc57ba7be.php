<?php $__env->startSection('content'); ?>
    <div class="container post">

    <div class="event">
        <h2>News</h2>
      <!--  <div class="row">
            <div class="col-md-12">
                <div class="event-head">
                    <img src="<?php echo e(asset ('images/report.jpg')); ?>" alt="" class="event-head-img">
                </div>
            </div>
        </div>
        <hr> -->
        <div class="row">
            <div class="col-md-12">
                <h3>1-Day Masterclass and Mentorship Series</h3>
<p>
This Masterclass series will help you to develop as a successful entrepreneur investing in healthcare delivery and related businesses in resource constraint setting. 
It promises to be informative, thorough, interesting, engaging and satisfying such that you are informed to make a decision to invest and operate in the Medical Imaging business.

Come prepared to share your problems and experiences as this Masterclass will be an interactive learning opportunity. Participants will be asked to complete an individual or group exercise putting what you’ve learned to use. 
<br>
How many times have you heard these comments?
<ul>
<li>	Setting up businesses are too daunting</li>
<li>	Medical Imaging Business  are too complex</li>
<li>	Diagnostics Business set-up are confusing</li>
<li>	I don’t see why we have to do this. </li>
<li>	Can I manage my staff</li>
</ul>
Entrepreneurship in Medical Imaging requires an understanding of the needs and the complexities of a growth mind set, top-notch corporate character and wielding substantial leverage to lead in innovation, technology and service excellence against the backdrop of certain distracting factors. 
<br>
What you will learn: 
<ul><li>	Health and Care development in emerging and growth market</li>
	<li>Principles of entrepreneurship</li>
<li>	Brands and Marketing</li>
<li>	Managing investors and financing</li>
<li>	Quality in health and care service provision</li>
<li>	Medico-Legal aspect of health and care business</li>
<li>	Leadership and peoples skills</li>
<li>	Professional and personal development assessment and planning</li>
</ul>
<div>Who should attend: </div>
Entrepreneurs who own a healthcare practice/ business, professionals who aspire to own their own healthcare business, health managers investors in health, others.
<br>
This Masterclass promises to deliver training that is designed to meet your specific needs</p>
            </div>
        </div>
    </div>

   
    </div>

        <!-- </ul> -->
    <!-- </div> -->

   
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/posts/index.blade.php ENDPATH**/ ?>