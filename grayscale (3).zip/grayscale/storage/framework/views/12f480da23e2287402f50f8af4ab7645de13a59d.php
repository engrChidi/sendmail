

<?php $__env->startSection('content'); ?>

    <div class="container">
                <div class="row">
                    <div class="col-md-12"><br>
                        <h2>Entrepreneurship Mentorship Program (EMP)</h2>
                        <div><a href="/mid" class="btn btn-outline-primary">Click here to Sign-up for this Program
                            </a></div> <div>Program leader  <b><a href="#">Felix O Erondu. PhD</a></b>
                        </div>

                    </div></div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card" style="width:100%; background-color: #efefef; border:none">
                            <img class="card-img-top"  src="http://codespace.com.ng/img/ent.png" alt="grayscale">
                            <div class="card-body">
                                <p class="card-text">
                This entrepreneurship mentorship program will help Health professionals interested in growing their business either as s startup or to expand an already existing enterprise into developing competencies that are crucial to achieving success in health care business. In several sessions, this master class will equip participants with skills in peoples leadership, business management, navigating regulatory codes and frameworks, risk and controllership,  and marketing development. In its mentorship program, the participant will learn from accomplished health entrepreneurs important tips and trick and be guided on how to replicate their success regardless of locality specific constraints.
</p></div></div>
                            </div>
                            <div class="col-md-6"  style="padding-left: 5px">
               <b> Aim:</b> to develop successful entrepreneurs in healthcare delivery and related businesses in resource constraint setting
                                <p><b>Objective:</b> To equip health professionals with essential entrepreneurship skills to develop or grow their business with consistent delivery of high quality, lowered risk and strong capital base

                </p> <b>Target audience:</b> Entrepreneurs who own a healthcare practice/ business, professionals who aspire to own their own healthcare business, health managers investors in health, others.

               <p><b>Structure</b> The 3-month mentorship program has e-mentorship sessions, didactic, and self-paced development plan
                </p>
                <b>Mode of delivery:</b> Online

              <p> <b>Topics area covered:</b>
               <ul><li>
                    Health and Care development  in emerging and growth market</li>
               <li>
                Principles of entrepreneurship</li>
               <li> Brands and Marketing</li>
              <li> Managing investors and financing</li>
                   <li>Quality in health and care service provision</li>
                    <li>Medico-Legal aspect of health and care business</li>
               <li>Leadership and peoples skills</li>
                   <li>Professional and personal development assessment and planning</li>
                </ul> <a href="/mid" class="btn btn-outline-primary">Click here to Sign-up for this Program
                            </a></p>
            </div>
            </div>

        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/training/entrepreneurship.blade.php ENDPATH**/ ?>