

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2" style="margin: auto"><br>
                <h5 align="center">  This mentorship program is adapted for medical imaging and radiation professionals and focuses on their Academic development , Entrepreneurship and Professional development.
                    </h5><h6>   You may want to <a href="/mentors" style="color: blue; text-decoration: underline">Meet our Experts</a> </h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 jumbotron">
<div class="row">
    <div class="col-md-4">
        <div class="card" style="width:100%">
            <img class="card-img-top"  src="http://codespace.com.ng/img/acad.png" alt="grayscale international">
            <div class="card-body">
                <h4 class="card-title"><a href="/academic" style="color: blue; text-decoration: underline"> Academic Mentorship Program</a>
                </h4>
                     </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card" style="width:100%">
            <img class="card-img-top"  src="http://codespace.com.ng/img/ent.png" alt="grayscale">
            <div class="card-body">
                <h4 class="card-title"><a href="/entrep" style="color: blue; text-decoration: underline">Entrepreneurship Mentorship (EMP)</a>
                </h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card" style="width:100%">
            <img class="card-img-top"  src="http://codespace.com.ng/img/ld.png" alt="grayscale international">
            <div class="card-body">
                <h4 class="card-title"><a href="/leader" style="color: blue; text-decoration: underline"> Professional Mentorship Program</a>
                </h4>
            </div>
        </div>
    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/coursedetails.blade.php ENDPATH**/ ?>