<?php $__env->startSection('content'); ?>
<div class="icon-bar">
    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
    <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
    <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
</div>
    <div class="services">
        <h2>Services</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="event-head">
                    <img src="<?php echo e(asset ('images/services.jpg')); ?>" alt="" class="event-head-img">
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="circle text-align-center">
                    
                    
                        <a href="/training" class="text-decoration-none">
                            <h5><strong>Training and Capacity Development</strong></h5>
                        </a>
                        
                </div>
            </div>
            <div class="col-md-6">
                <div class="circle2 text-align-center">
                    
                        <a href="/health" class="text-decoration-none">
                            <h5><strong>Health and Related Consultancy Services</strong></h5>
                        </a>
                        
                </div>
            </div>

        </div><br>
        <div class="row">
            <div class="col-md-6">
                <div class="circle3 text-align-center">
                    
                        <a href="/research" class="text-decoration-none">
                            <h5><strong>Market Access and Outcome Research</strong></h5>
                        </a>
                        
                </div>
            </div>
            <div class="col-md-6">
                <div class="circle4 text-align-center">
                    
                        <a href="/screen" class="text-decoration-none">
                            <h5><strong>Program Management and Advisory Service</strong></h5>
                        </a>
                        
                </div>
            </div>

        </div><br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/pages/service.blade.php ENDPATH**/ ?>