<?php $__env->startSection('content'); ?>


<div class="icon-bar">
    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
    <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
    <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
</div>
<section class="about" id="about">
        <div class="container">
                <h3><strong>Market Access and Outcome Research</strong></h3><br>
                <div class="row">
                        <div class="col-md-6">
                                <img src="<?php echo e(asset('images/research.jpeg')); ?>" alt="research" class="research-img">
                        </div>
                        <div class="col-md-6">
                        <p>GSI is positioned to drive evidence base improvement that promotes real health outcomes. Broadly we assist our partners and collaborators to:
                        <ol>
                                <li>Perform Field data management from Countries in Africa</li>
                                <li>Conduct implementation research related to product and programs effectiveness in the African context. Our outputs readily support market access for these products and services.</li>
                                <li>Coordinate a network of associates for multicountry implementation research based on the requirement of our customer/partners.</li>
                                <li>New product/Service Introduction; we assist our client to enter African markets in countries like Nigeria.</li>
                        </ol>
                </p>
                        </div>
                </div>
                <br>
        </div>
</section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/research.blade.php ENDPATH**/ ?>