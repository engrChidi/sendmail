<?php $__env->startSection('content'); ?>
    <div class="container post">

        <div class="event">
            <h2>Events</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="event-head">
                        <img src="<?php echo e(asset ('images/Lagos.jpg')); ?>" alt="" class="event-head-img">
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <p>This is the event page</p>
                </div>
            </div>
        </div>

    <?php if(count($events) > 0): ?>

    <!-- <div class="card"> -->
        <!-- <ul class="list-group list-group-flush"> -->

            <div class="row">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- <li class="list-group-item"> -->
                <div class="col-md-6 px-2">
            <div class="card mb-5" style="height: 150px">
        <div class="row">
            <div class="col-md-4" style="height: 150px">
                <img src="/storage/cover_images/<?php echo e($event->cover_image); ?>" alt="" style="width: 100%;height: 100%;object-fit: cover">
            </div>
            <div class="col-md-8 pl-5 pt-3 pb-2">
                <h1><a href="/event/<?php echo e($event->id); ?>" class="text-decoration-none"><?php echo e($event->title); ?></a></h1>
                <small>Written at <?php echo e($event->created_at); ?></small>
            </div>
            <hr>
        </div>
            </div>
                </div>
        <!-- </li> -->

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

        <!-- </ul> -->
    <!-- </div> -->

    <?php else: ?>

    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/events/index.blade.php ENDPATH**/ ?>