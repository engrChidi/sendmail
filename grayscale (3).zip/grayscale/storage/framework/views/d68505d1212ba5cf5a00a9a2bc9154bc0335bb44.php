<?php $__env->startSection('content'); ?>
<div class="container mb-5">
    <div class="home">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-5">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <a href="/post/create" class='btn btn-primary mt-3 mb-5'>Create Post</a>
                    <a href="/project/create" class='btn btn-primary mt-3 mb-5'>Create Project</a>
                    <a href="/event/create" class='btn btn-primary mt-3 mb-5'>Create Event</a>
                    <div class="row">
                        <div class="col-md-12">
                            <nav>
                                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Posts</a>
                                    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Projects</a>
                                    <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Events</a>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <?php if(count($posts) > 0): ?>
                    <table class="table table-striped">
                        <tr>
                            <th>Image</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><img src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="" style="width: 100px; height:100px; object-fit:cover"></th>
                            <th><a href="/post/<?php echo e($post->id); ?>" class="text-decoration-none"><?php echo e($post->title); ?></a></th>
                            <th><a href="/post/<?php echo e($post->id); ?>/edit" class="btn btn-success">Edit</a></th>
                            <th>
                                <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                                <?php echo Form::close(); ?>

                            </th>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                    <?php else: ?>


                    <?php endif; ?>
                </div>
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                    <?php if(count($projects) > 0): ?>
                    <table class="table table-striped">
                        <tr>
                            <th>Image</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><img src="/storage/cover_images/<?php echo e($project->cover_image); ?>" alt="" style="width: 100px; height:100px; object-fit:cover"></th>
                            <th><a href="/post/<?php echo e($project->id); ?>" class="text-decoration-none"><?php echo e($project->title); ?></a></th>
                            <th><a href="/post/<?php echo e($project->id); ?>/edit" class="btn btn-success">Edit</a></th>
                            <th>
                                <?php echo Form::open(['action' => ['ProjectController@destroy', $project->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                                <?php echo Form::close(); ?>

                            </th>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                    <?php else: ?>


                    <?php endif; ?>
                </div>
                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                    <?php if(count($events) > 0): ?>
                    <table class="table table-striped">
                        <tr>
                            <th>Image</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><img src="/storage/cover_images/<?php echo e($event->cover_image); ?>" alt="" style="width: 100px; height:100px; object-fit:cover"></th>
                            <th><a href="/post/<?php echo e($event->id); ?>" class="text-decoration-none"><?php echo e($event->title); ?></a></th>
                            <th><a href="/post/<?php echo e($event->id); ?>/edit" class="btn btn-success">Edit</a></th>
                            <th>
                                <?php echo Form::open(['action' => ['EventController@destroy', $event->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                                <?php echo Form::close(); ?>

                            </th>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                    <?php else: ?>


                    <?php endif; ?>
                </div>
            </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/home.blade.php ENDPATH**/ ?>