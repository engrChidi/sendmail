<?php $__env->startSection('content'); ?>
    <div class="container post">

        <div class="event">
            <h2>Projects</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="event-head">
                        <img src="<?php echo e(asset ('images/project.jpg')); ?>" alt="" class="event-head-img">
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <p><marquee>...To be updated with ongoing projects been implemented</marquee></p>
                </div>
            </div>
        </div>

   
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/projects/index.blade.php ENDPATH**/ ?>