<?php $__env->startSection('content'); ?>
    <div class="container post">

        <div class="event">
            <h2>Projects</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="event-head">
                        <img src="<?php echo e(asset ('images/project.jpg')); ?>" alt="" class="event-head-img">
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <p>This is the project page</p>
                </div>
            </div>
        </div>

    <?php if(count($projects) > 0): ?>

    <!-- <div class="card"> -->
        <!-- <ul class="list-group list-group-flush"> -->

            <div class="row">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- <li class="list-group-item"> -->
                <div class="col-md-6 px-2">
            <div class="card mb-5" style="height: 150px">
        <div class="row">
            <div class="col-md-4" style="height: 150px">
                <img src="/storage/cover_images/<?php echo e($project->cover_image); ?>" alt="" style="width: 100%;height: 100%;object-fit: cover">
            </div>
            <div class="col-md-8 pl-5 pt-3 pb-2">
                <h1><a href="/project/<?php echo e($project->id); ?>" class="text-decoration-none"><?php echo e($project->title); ?></a></h1>
                <small>Written at <?php echo e($project->created_at); ?></small>
            </div>
            <hr>
        </div>
            </div>
                </div>
        <!-- </li> -->

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

        <!-- </ul> -->
    <!-- </div> -->

    <?php else: ?>

    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grayscale\resources\views/projects/index.blade.php ENDPATH**/ ?>