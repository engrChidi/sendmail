

<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>

        <h3 align="center" style="color: blue">GSi MasterClass Series.</h3> <div align="center">Entrepreneurship in Medical Imaging and Radiation Therapy</div>

       <h4 align="center" style="color: red">Online Survey Questionnaire</h4>
        <hr align="center" style="width: 50%">


        <form method="post" action="<?php echo e(route('survy.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-md-8 col-md-offset-2" style="margin: auto">
                    <div id="xxx3">
                        <div class="panel panel-default">
                            <div class="panel panel-heading panel-warning" align="center"><b>Consent Notification</b></div>
                            <div class="panel panel-body">The information you will provide could be used for our service improvement, research and development purposes only.  It will be held in confidentiality and anonymity. By continuing this survey, you admit this terms.
                            </div>
                            <div class="panel panel-footer panel-default" align="center"><a href="/" class="btn btn-dark">Decline</a>  &nbsp; <button class=" btn btn-warning" id="xxx3b">Proceed</button> </div>
                        </div>
                    </div>

                            <div id="xxx1">
                              <h2> 1.0 General Section</h2>

                                <div class="form-group">
                        <lable>Sex</lable>
                        <select name="sex" class="form-control" required>
                            <option value="">Select gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Country</label>
                        <select class="form-control" name="country" required>
                            <option hidden>Select Country</option>
                            <option value="afghanistan">Afghanistan</option>
                            <option value="albania">Albania</option>
                            <option value="algeria">Algeria</option>
                            <option value="andorra">Andorra</option>
                            <option value="angola">Angola</option>
                            <option value="antigua_and_barbuda">Antigua and Barbuda</option>
                            <option value="argentina">Argentina</option>
                            <option value="armenia">Armenia</option>
                            <option value="australia">Australia</option>
                            <option value="austria">Austria</option>
                            <option value="azerbaijan">Azerbaijan</option>
                            <option value="bahamas">Bahamas</option>
                            <option value="bahrain">Bahrain</option>
                            <option value="bangladesh">Bangladesh</option>
                            <option value="barbados">Barbados</option>
                            <option value="belarus">Belarus</option>
                            <option value="belgium">Belgium</option>
                            <option value="belize">Belize</option>
                            <option value="benin">Benin</option>
                            <option value="bhutan">Bhutan</option>
                            <option value="bolivia">Bolivia</option>
                            <option value="bosnia_and_herzegovina">Bosnia and Herzegovina</option>
                            <option value="botswana">Botswana</option>
                            <option value="brazil">Brazil</option>
                            <option value="brunei">Brunei</option>
                            <option value="bulgaria">Bulgaria</option>
                            <option value="burkina_faso">Burkina Faso</option>
                            <option value="burundi">Burundi</option>
                            <option value="cabo_verde">Cabo Verde</option>
                            <option value="cambodia">Cambodia</option>
                            <option value="cameroon">Cameroon</option>
                            <option value="canada">Canada</option>
                            <option value="central_african_republic">Central African Republic (CAR)</option>
                            <option value="chad">Chad</option>
                            <option value="chile">Chile</option>
                            <option value="china">China</option>
                            <option value="colombia">Colombia</option>
                            <option value="comoros">Comoros</option>
                            <option value="congo">Congo</option>
                            <option value="costa_rica">Costa Rica</option>
                            <option value="cote_d'ivoire">Cote d'Ivoire</option>
                            <option value="croatia">Croatia</option>
                            <option value="cuba">Cuba</option>
                            <option value="cyprus">Cyprus</option>
                            <option value="czechia">Czechia</option>
                            <option value="denmark">Denmark</option>
                            <option value="djibouti">Djibouti</option>
                            <option value="dominica">Dominica</option>
                            <option value="dominican_republic">Dominican Republic</option>
                            <option value="ecuador">Ecuador</option>
                            <option value="egypt">Egypt</option>
                            <option value="el_salvador">El Salvador</option>
                            <option value="equatorial Guinea">Equatorial Guinea</option>
                            <option value="eritrea">Eritrea</option>
                            <option value="estonia">Estonia</option>
                            <option value="eswatini">Eswatini</option>
                            <option value="ethiopia">Ethiopia</option>
                            <option value="fiji">Fiji</option>
                            <option value="finland">Finland</option>
                            <option value="france">France</option>
                            <option value="gabon">Gabon</option>
                            <option value="gambia">Gambia</option>
                            <option value="georgia">Georgia</option>
                            <option value="germany">Germany</option>
                            <option value="ghana">Ghana</option>
                            <option value="greece">Greece</option>
                            <option value="grenada">Grenada</option>
                            <option value="guatemala">Guatemala</option>
                            <option value="guinea">Guinea</option>
                            <option value="guinea_bissau">Guinea-Bissau</option>
                            <option value="guyana">Guyana</option>
                            <option value="haiti">Haiti</option>
                            <option value="honduras">Honduras</option>
                            <option value="hungary">Hungary</option>
                            <option value="iceland">Iceland</option>
                            <option value="india">India</option>
                            <option value="indonesia">Indonesia</option>
                            <option value="iran">Iran</option>
                            <option value="iraq">Iraq</option>
                            <option value="ireland">Ireland</option>
                            <option value="israel">Israel</option>
                            <option value="italy">Italy</option>
                            <option value="jamaica">Jamaica</option>
                            <option value="japan">Japan</option>
                            <option value="jordan">Jordan</option>
                            <option value="kazakhstan">Kazakhstan</option>
                            <option value="kenya">Kenya</option>
                            <option value="kiribati">Kiribati</option>
                            <option value="kosovo">Kosovo</option>
                            <option value="kuwait">Kuwait</option>
                            <option value="kyrgyzstan">Kyrgyzstan</option>
                            <option value="laos">Laos</option>
                            <option value="latvia">Latvia</option>
                            <option value="lebanon">Lebanon</option>
                            <option value="lesotho">Lesotho</option>
                            <option value="liberia">Liberia</option>
                            <option value="libya">Libya</option>
                            <option value="liechtenstein">Liechtenstein</option>
                            <option value="lithuania">Lithuania</option>
                            <option value="luxembourg">Luxembourg</option>
                            <option value="madagascar">Madagascar</option>
                            <option value="malawi">Malawi</option>
                            <option value="malaysia">Malaysia</option>
                            <option value="maldives">Maldives</option>
                            <option value="mali">Mali</option>
                            <option value="malta">Malta</option>
                            <option value="marshall_islands">Marshall Islands</option>
                            <option value="mauritania">Mauritania</option>
                            <option value="mauritius">Mauritius</option>
                            <option value="mexico">Mexico</option>
                            <option value="micronesia">Micronesia</option>
                            <option value="moldova">Moldova</option>
                            <option value="monaco">Monaco</option>
                            <option value="mongolia">Mongolia</option>
                            <option value="montenegro">Montenegro</option>
                            <option value="morocco">Morocco</option>
                            <option value="mozambique">Mozambique</option>
                            <option value="myanmar">Myanmar </option>
                            <option value="namibia">Namibia</option>
                            <option value="nauru">Nauru</option>
                            <option value="nepal">Nepal</option>
                            <option value="netherlands">Netherlands</option>
                            <option value="new_zealand">New Zealand</option>
                            <option value="nicaragua">Nicaragua</option>
                            <option value="niger">Niger</option>
                            <option value="nigeria">Nigeria</option>
                            <option value="north_korea">North Korea</option>
                            <option value="north_macedonia">North Macedonia </option>
                            <option value="norway">Norway</option>
                            <option value="oman">Oman</option>
                            <option value="pakistan">Pakistan</option>
                            <option value="palau">Palau</option>
                            <option value="palestine">Palestine</option>
                            <option value="panama">Panama</option>
                            <option value="papua_new_guinea">Papua New Guinea</option>
                            <option value="paraguay">Paraguay</option>
                            <option value="peru">Peru</option>
                            <option value="philippines">Philippines</option>
                            <option value="poland">Poland</option>
                            <option value="portugal">Portugal</option>
                            <option value="qatar">Qatar</option>
                            <option value="romania">Romania</option>
                            <option value="russia">Russia</option>
                            <option value="rwanda">Rwanda</option>
                            <option value="saint_kitts_and_nevis">Saint Kitts and Nevis</option>
                            <option value="saint_lucia">Saint Lucia</option>
                            <option value="saint_vincent_and_the_grenadines">Saint Vincent and the Grenadines</option>
                            <option value="samoa">Samoa</option>
                            <option value="san_marino">San Marino</option>
                            <option value="sao_tome_and_principe">Sao Tome and Principe</option>
                            <option value="saudi_arabia">Saudi Arabia</option>
                            <option value="senegal">Senegal</option>
                            <option value="serbia">Serbia</option>
                            <option value="seychelles">Seychelles</option>
                            <option value="sierra_leone">Sierra Leone</option>
                            <option value="singapore">Singapore</option>
                            <option value="slovakia">Slovakia</option>
                            <option value="slovenia">Slovenia</option>
                            <option value="solomon_islands">Solomon Islands</option>
                            <option value="somalia">Somalia</option>
                            <option value="south_africa">South Africa</option>
                            <option value="south_korea">South Korea</option>
                            <option value="south_sudan">South Sudan</option>
                            <option value="spain">Spain</option>
                            <option value="sri_lanka">Sri Lanka</option>
                            <option value="sudan">Sudan</option>
                            <option value="suriname">Suriname</option>
                            <option value="sweden">Sweden</option>
                            <option value="switzerland">Switzerland</option>
                            <option value="syria">Syria</option>
                            <option value="taiwan">Taiwan</option>
                            <option value="tajikistan">Tajikistan</option>
                            <option value="tanzania">Tanzania</option>
                            <option value="thailand">Thailand</option>
                            <option value="timor_leste">Timor-Leste</option>
                            <option value="togo">Togo</option>
                            <option value="tonga">Tonga</option>
                            <option value="trinidad_and_tobago">Trinidad and Tobago</option>
                            <option value="tunisia">Tunisia</option>
                            <option value="turkey">Turkey</option>
                            <option value="turkmenistan">Turkmenistan</option>
                            <option value="tuvalu">Tuvalu</option>
                            <option value="uganda">Uganda</option>
                            <option value="ukraine">Ukraine</option>
                            <option value="united_arab_emirates">United Arab Emirates (UAE)</option>
                            <option value="united_kingdom">United Kingdom (UK)</option>
                            <option value="united_states_of_america">United States of America (USA)</option>
                            <option value="uruguay">Uruguay</option>
                            <option value="uzbekistan">Uzbekistan</option>
                            <option value="vanuatu">Vanuatu</option>
                            <option value="vatican_city">Vatican City (Holy See)</option>
                            <option value="venezuela">Venezuela</option>
                            <option value="vietnam">Vietnam</option>
                            <option value="yemen">Yemen</option>
                            <option value="zambia">Zambia</option>
                            <option value="zimbabwe">Zimbabwe</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Email">Age Range:</label>
                        <select name="age" class="form-control" required>
                            <option value="">-- Select --</option>
                            <option value="< 25 ">< 25 </option>
                            <option value="25-30">25-30 </option>
                            <option value="31-35">31-35 </option>
                            <option value="36-40">36-40 </option>
                            <option value="41-45">41-45 </option>
                            <option value="46-50">46-50 </option>
                            <option value="51-55">51-55 </option>
                            <option value="56-60">56-60 </option>
                            <option value="> 60"> > 60</option>
                        </select>
</div>
                    <div class="form-group">
                        <label for="Number">Qualification</label>
                        <select name="qualification" class="form-control" required>
                            <option value="">Select one</option>
                            <option value="Radiographer/Rad Technologist">Radiographer/Rad Technologist </option>
                            <option value="Sonographer">Sonographer </option>
                            <option value="Radiologist">Radiologist </option>
                            <option value="Investor">Investor </option>
                            <option value="Other Health Professional">Other Health Professional</option>
                                                   </select>
                      
                    </div>
                        <div class="form-group">
                            <label for="Number">Highest Qualification </label>
                            <select name="academic" class="form-control" required>
                                <option value="">Select one</option>
                                <option value="Diploma">Diploma</option>
                                <option value="Higher national Diploma">Higher National Diploma</option>
                                <option value="B.Sc">B.Sc </option>
                                <option value="PG Diploma">PG Diploma</option>
                                <option value="M.Sc">M.Sc</option>
                                <option value="PhD">PhD</option>
                                <option value="BA">BA</option>
                                <option value="MBA">MBA</option>
                                <option value="Others">Others</option>
                            </select>

                        </div>


                    <div class="form-group">
                        <label for="Number">Years Since first Qualification in Medical Imaging or Radiation therapy</label>
                        <input type="number" placeholder="..." name="years" required class="form-control" />
                    </div>
                        <div class="form-group"><label for="Number">Do you own a Business or a leader in a private
                                enterprise in any field of Medical Imaging or
                                Radiation therapy?
                            </label>
                            <select name="do" class="form-control" required>
                                <option value="">-- Select --</option>     
                                <option value="Yes">Yes</option>     
                                <option value="No">No</option>  
                                </select>
                        </div>
                        <div class="form-group">
                            <label for="Number">Years since start of Business </label>
                            <input type="number" placeholder="..." name="start" required  class="form-control"/>
                        </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-success" id="xxxb">Next >></button>
                        </div>
                    </div>

                    <div id="xxx2"><br>
                        <h2>2.0 Business</h2>
                        <div class="form-group">
                            <h5><label for="Number">2.1 Select equipment in your business </label></h5>

                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Mobile X Ray">Mobile X Ray</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Static X ray">Static X ray</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="MRI">MRI</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Computed Tomography T">Computed Tomography T</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Fluoroscopy">Fluoroscopy</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Other Laboratory Services">Other Laboratory Services</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="ECG">ECG</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Interventional Suit">Interventional Suit</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Cath Lab">Cath Lab</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="CT Simulators">CT Simulators</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Linac [Brachytherapy]">Linac [Brachytherapy]</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="3 or 4D Ultrasound">3/4D Ultrasound</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Mammography">Mammography</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Dental X-ray">Dental X-ray</label> &nbsp;
                                <label><input type="checkbox"  class="kxxx" name="equipment[]" value="Echocardiography">Echocardiography</label> &nbsp;

                        </div>
                    <div class="form-group">
                            <label for="Number">2.2 What was your estimated capital at start-up? </label>
                            <select name="capital" required class="form-control">
                                <option value="">Select one</option>
                                <option value="<10,000 USD"><10,000 USD</option>
                                <option value="<20,000 USD"><20,000 USD</option>
                                <option value="<30,000 USD"><30,000 USD</option>
                                <option value="<40,000 USD"><40,000 USD</option>
                                <option value="<50,000 USD"><50,000 USD</option>
                                <option value="<100,000 USD"><100,000 USD</option>
                                <option value="<200,000 USD"><200,000 USD</option>
                                <option value="> 200,000 USD">> 200,000 USD</option>
                               </select>
                        </div>
                                              <div class="form-group">
                            <label for="Number">2.3 What was your estimated capital at start-up?</label>
                            <select name="current" required class="form-control">
                                <option value="">Select one</option>
                                <option value="<50,000 USD"><50,000 USD</option>
                                <option value=">51,000 USD">>51,000 USD</option>
                                <option value="<100,000 USD"><100,000 USD</option>
                                <option value="<150,000 USD"><150,000 USD</option>
                                <option value="<200,000 USD"><200,000 USD</option>
                                <option value="<300,000 USD"><300,000 USD</option>
                                <option value="<500,000 USD"><500,000 USD</option>
                                <option value="<1M USD"><1M USD</option>
                                <option value="<3M USD"><3M USD</option>
                                <option value="<5M  USD"><5M USD</option>
                                <option value="<10M  USD"><10M USD</option>
                                <option value=">10.1M USD">> 10.1M USD</option>
                            </select>
                        </div>


                        <div class="form-group">
                            <h5> <label for="Number"><b>2.4 List three top needs of your business?</b></label></h5>
                        <label><input type="checkbox" name="bizneed[]" value="Financing" class="kxxx">Financing</label> &nbsp;
                        <label><input type="checkbox" name="bizneed[]" value="Medico legal support"  class="kxxx">Medico legal support</label> &nbsp;
                        <label><input type="checkbox" name="bizneed[]" value="Human Resource efficiency" class="kxxx">Human Resource efficiency </label> &nbsp;
                        <label><input type="checkbox" name="bizneed[]" value="Market development" class="kxxx">Market development</label> &nbsp;
                        <label><input type="checkbox" class="kxxx" name="bizneed[]" value="Advertising and communications">Advertising and communications</label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Business Management Skills and training ">Business Management Skills and training</label> &nbsp;
                        <label><input type="checkbox" class="kxxx" name="bizneed[]" value="Outdated Equipment">Outdated Equipment </label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Bigger Building">Bigger Building </label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Network Infrastructure">Network Infrastructure</label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Access to Bank financing">Access to Bank financing</label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Prolong reporting time">Prolong reporting time</label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Reliable Equipment engineering partners">Reliable Equipment engineering partners</label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Expansion to new locality">Expansion to new locality</label> &nbsp;
                        <label><input type="checkbox"  class="kxxx" name="bizneed[]" value="Improvement in workers attitude or workplace culture">Improvement in workers attitude or workplace culture</label> &nbsp;
                   </div>
                        <div class="form-group"><br>
                          <h5>  <label for="Number"><b>2.5 List top two needs of your customer</b></label></h5>
                            <label><input type="checkbox"  class="kxxx" name="cusneed[]" value="Service efficiency">Service efficiency</label>
                            <label><input type="checkbox"  class="kxxx" name="cusneed[]" value="Quality reports">Quality reports</label>
                            <label><input type="checkbox"  class="kxxx" name="cusneed[]" value="Friendly Ambience ">Friendly Ambience </label>
                            <label><input type="checkbox"  class="kxxx" name="cusneed[]" value="One-stop-shop">One-stop-shop</label>
                                                 </div>

                        <div class="form-group">
                            <label for="Number">2.6 Mention the next equipment/service your will immediately add to your service portfolio</label>
                            <select name="next" required class="form-control">
                                <option value="">-- Select --</option>
                                <option value="Mobile X Ray">Mobile X Ray</option>
                                <option value="Static X ray">Static X ray</option>
                                <option value="Ultrasound">Ultrasound</option>
                                <option value="MRI">MRI</option>
                                <option value="Computed Tomography T">Computed Tomography T</option>
                                <option value="Fluoroscopy">Fluoroscopy</option>
                                <option value="Other Laboratory Services">Other Laboratory Services</option>
                                <option value="ECG ">ECG </option>
                                <option value="Interventional Suit ">Interventional Suit </option>
                                <option value="Cath Lab ">Cath Lab </option>
                                <option value="CT Simulators">CT Simulators </option>
                                <option value="Linac">Linac </option>
                                <option value="Brachytherapy">Brachytherapy </option>
                                <option value="Mammography">Mammography </option>
                                <option value="3/4D Ultrasound">3/4D Ultrasound</option>
                                <option value="Dental X-ray">Dental X-ray</option>
                                <option value="Dental X-ray">Dental X-ray</option>
                                <option value="Echocardiography">Echocardiography</option>
</select></div>

                        <div class="form-group"><label for="Number">2.7 How many staff works for you currently?</label>
                            <input type="text" placeholder="..." name="staff" required class="form-control" /> </div>
                        <div class="form-group">
                            <label for="Number">2.8 Select the word that best describe your experience in business
                               </label>
                                <select name="experience" required class="form-control">
                                <option value="">-- Select --</option>
                                <option value="Satisfying">Satisfying</option>
                                <option value="Challenging">Challenging</option>
                                <option value="Exasperating">Exasperating</option>
                                <option value="Uncertain">Uncertain</option>
</select> </div>
                            <div class="form-group">
                                <label for="Number">2.9 Identify your immediate strategic business need
                                </label>
                                <select name="strategic" required class="form-control">
                                    <option value="">-- Select --</option>
                                    <option value="Investor">Investor</option>
                                    <option value="Partners">Partners</option>
                                    <option value="Effective Leadership">Effective Leadership</option>
                                    <option value="Management team">Management team</option>
                                    <option value="Marketing">Marketing</option>
                                    <option value="Equipment Maintenance">Equipment Maintenance</option>
                                    <option value="Productive work culture">Productive work culture</option>
                                    <option value="Workers loyalty/stewardship">Workers loyalty/stewardship</option>
                                    <option value="Effective consumable supply chain">Effective consumable supply chain</option>
                                    <option value="Client Satisfaction">Client Satisfaction</option>
                                    <option value="Others">Others</option>
</select></div>
                                                       <div class="form-group">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                    </div></div></div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/training/survey.blade.php ENDPATH**/ ?>