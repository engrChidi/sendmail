<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- Script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' type='text/javascript'></script>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js" defer></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="<?php echo e(asset('css/font/css/font-awesome.css')); ?>" rel="stylesheet">

    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md shadow-sm pt-3 pb-3">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <strong>grayscale</strong> International<br>
                    Improving Health Outcome
                </a>
                
                    

                <!---->
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav search ml-1 mr-auto">
                        <form action="<?php echo e(route('post.index')); ?>" method="GET" role="search">

                            <div class="input-group ml-3 mt-2">
                                <input type="text" class="form-control" name="term" placeholder="Search posts"
                                    id="term">
                                <span class="input-group-btn">
                                    <button class="btn px-0 pl-1" type="submit" title="Search projects">
                                        <span class="fa fa-search"></span>
                                    </button>
                                </span>
                                
                            </div>
                        </form>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <div class="mobile">
                    <div id="mySidenav" class="sidenav">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                        <ul class="navbar-nav menu ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#update">Update</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/about">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Services</a>
                            <ul class="sub-menu navbar-nav">
                                <li class="nav-item">
                                <a class="nav-link" href="/training">Training and Capacity Development</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="/health">Health and Related Consultancy Services</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="/research">Market Access and Outcome Research</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="/screen">Program Management and Advisory Service</a>
                                </li>
                            </ul>
                        </li>
                        <?php if(auth()->guard()->guest()): ?>

                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/home">
                                    Dashboard
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                        </ul>
                      </div>

                      <span style="font-size:20px;cursor:pointer;right:10px" onclick="openNav()">&#9776;</span>
                    </div>
                    <ul class="navbar-nav ml-auto desktop">

                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#update">Update</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/about">About</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="/#services" id="navbarDropdown"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>Services</a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/training">Training and Capacity Development</a>
                                <a class="dropdown-item" href="/health">Health and Related Consultancy Services</a>
                                <a class="dropdown-item" href="/research">Market Access and Outcome Research</a>
                                <a class="dropdown-item" href="/screen">Program Management and Advisory Service</a>
                            </div>
                        </li>



                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>

                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/home">
                                    Dashboard
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="">
            <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <section class="contact" id="contact">
        <div class="container">
            <h3><strong>Contact Us</strong></h3><br>

            <form action="" method="post" action="">

    <?php echo csrf_field(); ?>

    <div class="form-group">
        <div class="row">
            <div class="col-md-6">
                <span class="require">*</span>
                <input type="text" class="form-control divide <?php echo e($errors->has('first_name') ? 'error' : ''); ?>" name="first_name" id="first_name" placeholder="First Name" required>

                <!-- Error -->
        <?php if($errors->has('first_name')): ?>
        <div class="error">
            <?php echo e($errors->first('first_name')); ?>

        </div>
        <?php endif; ?>
            </div>
            <div class="col-md-6">
                <span class="require">*</span>
                <input type="text" class="form-control divide <?php echo e($errors->has('last_name') ? 'error' : ''); ?>" name="last_name" id="last_name" placeholder="Last Name" required>

                <!-- Error -->
        <?php if($errors->has('last_name')): ?>
        <div class="error">
            <?php echo e($errors->first('last_name')); ?>

        </div>
        <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="row">
            <div class="col-md-6">
        <span class="require">*</span>
        <input type="email" class="form-control divide <?php echo e($errors->has('email') ? 'error' : ''); ?>" name="email" id="email" placeholder="Email" required>


        <?php if($errors->has('email')): ?>
        <div class="error">
            <?php echo e($errors->first('email')); ?>

        </div>
        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                    <label></label>
        <input type="text" class="form-control divide <?php echo e($errors->has('phone') ? 'error' : ''); ?>" name="phone" id="phone" placeholder="Phone">

        <?php if($errors->has('phone')): ?>
        <div class="error">
            <?php echo e($errors->first('phone')); ?>

        </div>
        <?php endif; ?>
                    </div>

    </div>

    <div class="form-group">
        <div class="row">
            <div class="col-md-6">
                <span class="require">*</span>
                <select class="form-control divide <?php echo e($errors->has('country') ? 'error' : ''); ?>" name="country" id="country" required>
                    <option hidden>Select Country</option>
                   <option value="afghanistan">Afghanistan</option>
                   <option value="albania">Albania</option>
                    <option value="algeria">Algeria</option>
                    <option value="andorra">Andorra</option>
                    <option value="angola">Angola</option>
                    <option value="antigua_and_barbuda">Antigua and Barbuda</option>
                    <option value="argentina">Argentina</option>
                    <option value="armenia">Armenia</option>
                    <option value="australia">Australia</option>
                    <option value="austria">Austria</option>
                    <option value="azerbaijan">Azerbaijan</option>
                    <option value="bahamas">Bahamas</option>
                    <option value="bahrain">Bahrain</option>
                    <option value="bangladesh">Bangladesh</option>
                    <option value="barbados">Barbados</option>
                    <option value="belarus">Belarus</option>
                    <option value="belgium">Belgium</option>
                    <option value="belize">Belize</option>
                    <option value="benin">Benin</option>
                    <option value="bhutan">Bhutan</option>
                    <option value="bolivia">Bolivia</option>
                    <option value="bosnia_and_herzegovina">Bosnia and Herzegovina</option>
                    <option value="botswana">Botswana</option>
                    <option value="brazil">Brazil</option>
                    <option value="brunei">Brunei</option>
                    <option value="bulgaria">Bulgaria</option>
                    <option value="burkina_faso">Burkina Faso</option>
                    <option value="burundi">Burundi</option>
                    <option value="cabo_verde">Cabo Verde</option>
                    <option value="cambodia">Cambodia</option>
                    <option value="cameroon">Cameroon</option>
                    <option value="canada">Canada</option>
                    <option value="central_african_republic">Central African Republic (CAR)</option>
                    <option value="chad">Chad</option>
                    <option value="chile">Chile</option>
                    <option value="china">China</option>
                    <option value="colombia">Colombia</option>
                    <option value="comoros">Comoros</option>
                    <option value="congo">Congo</option>
                    <option value="costa_rica">Costa Rica</option>
                    <option value="cote_d'ivoire">Cote d'Ivoire</option>
                    <option value="croatia">Croatia</option>
                    <option value="cuba">Cuba</option>
                    <option value="cyprus">Cyprus</option>
                    <option value="czechia">Czechia</option>
                    <option value="denmark">Denmark</option>
                    <option value="djibouti">Djibouti</option>
                    <option value="dominica">Dominica</option>
                    <option value="dominican_republic">Dominican Republic</option>
                    <option value="ecuador">Ecuador</option>
                    <option value="egypt">Egypt</option>
                    <option value="el_salvador">El Salvador</option>
                    <option value="equatorial Guinea">Equatorial Guinea</option>
                    <option value="eritrea">Eritrea</option>
                    <option value="estonia">Estonia</option>
                    <option value="eswatini">Eswatini</option>
                    <option value="ethiopia">Ethiopia</option>
                    <option value="fiji">Fiji</option>
                    <option value="finland">Finland</option>
                    <option value="france">France</option>
                    <option value="gabon">Gabon</option>
                    <option value="gambia">Gambia</option>
                    <option value="georgia">Georgia</option>
                    <option value="germany">Germany</option>
                    <option value="ghana">Ghana</option>
                    <option value="greece">Greece</option>
                    <option value="grenada">Grenada</option>
                    <option value="guatemala">Guatemala</option>
                    <option value="guinea">Guinea</option>
                    <option value="guinea_bissau">Guinea-Bissau</option>
                    <option value="guyana">Guyana</option>
                    <option value="haiti">Haiti</option>
                    <option value="honduras">Honduras</option>
                    <option value="hungary">Hungary</option>
                    <option value="iceland">Iceland</option>
                    <option value="india">India</option>
                    <option value="indonesia">Indonesia</option>
                    <option value="iran">Iran</option>
                    <option value="iraq">Iraq</option>
                    <option value="ireland">Ireland</option>
                    <option value="israel">Israel</option>
                    <option value="italy">Italy</option>
                    <option value="jamaica">Jamaica</option>
                    <option value="japan">Japan</option>
                    <option value="jordan">Jordan</option>
                    <option value="kazakhstan">Kazakhstan</option>
                    <option value="kenya">Kenya</option>
                    <option value="kiribati">Kiribati</option>
                    <option value="kosovo">Kosovo</option>
                    <option value="kuwait">Kuwait</option>
                    <option value="kyrgyzstan">Kyrgyzstan</option>
                    <option value="laos">Laos</option>
                    <option value="latvia">Latvia</option>
                    <option value="lebanon">Lebanon</option>
                    <option value="lesotho">Lesotho</option>
                    <option value="liberia">Liberia</option>
                    <option value="libya">Libya</option>
                    <option value="liechtenstein">Liechtenstein</option>
                    <option value="lithuania">Lithuania</option>
                    <option value="luxembourg">Luxembourg</option>
                    <option value="madagascar">Madagascar</option>
                    <option value="malawi">Malawi</option>
                    <option value="malaysia">Malaysia</option>
                    <option value="maldives">Maldives</option>
                    <option value="mali">Mali</option>
                    <option value="malta">Malta</option>
                    <option value="marshall_islands">Marshall Islands</option>
                    <option value="mauritania">Mauritania</option>
                    <option value="mauritius">Mauritius</option>
                    <option value="mexico">Mexico</option>
                    <option value="micronesia">Micronesia</option>
                    <option value="moldova">Moldova</option>
                    <option value="monaco">Monaco</option>
                    <option value="mongolia">Mongolia</option>
                    <option value="montenegro">Montenegro</option>
                    <option value="morocco">Morocco</option>
                    <option value="mozambique">Mozambique</option>
                    <option value="myanmar">Myanmar </option>
                    <option value="namibia">Namibia</option>
                    <option value="nauru">Nauru</option>
                    <option value="nepal">Nepal</option>
                    <option value="netherlands">Netherlands</option>
                    <option value="new_zealand">New Zealand</option>
                    <option value="nicaragua">Nicaragua</option>
                    <option value="niger">Niger</option>
                    <option value="nigeria">Nigeria</option>
                    <option value="north_korea">North Korea</option>
                    <option value="north_macedonia">North Macedonia </option>
                    <option value="norway">Norway</option>
                    <option value="oman">Oman</option>
                    <option value="pakistan">Pakistan</option>
                    <option value="palau">Palau</option>
                    <option value="palestine">Palestine</option>
                    <option value="panama">Panama</option>
                    <option value="papua_new_guinea">Papua New Guinea</option>
                    <option value="paraguay">Paraguay</option>
                    <option value="peru">Peru</option>
                    <option value="philippines">Philippines</option>
                    <option value="poland">Poland</option>
                    <option value="portugal">Portugal</option>
                    <option value="qatar">Qatar</option>
                    <option value="romania">Romania</option>
                    <option value="russia">Russia</option>
                    <option value="rwanda">Rwanda</option>
                    <option value="saint_kitts_and_nevis">Saint Kitts and Nevis</option>
                    <option value="saint_lucia">Saint Lucia</option>
                    <option value="saint_vincent_and_the_grenadines">Saint Vincent and the Grenadines</option>
                    <option value="samoa">Samoa</option>
                    <option value="san_marino">San Marino</option>
                    <option value="sao_tome_and_principe">Sao Tome and Principe</option>
                    <option value="saudi_arabia">Saudi Arabia</option>
                    <option value="senegal">Senegal</option>
                    <option value="serbia">Serbia</option>
                    <option value="seychelles">Seychelles</option>
                    <option value="sierra_leone">Sierra Leone</option>
                    <option value="singapore">Singapore</option>
                    <option value="slovakia">Slovakia</option>
                    <option value="slovenia">Slovenia</option>
                    <option value="solomon_islands">Solomon Islands</option>
                    <option value="somalia">Somalia</option>
                    <option value="south_africa">South Africa</option>
                    <option value="south_korea">South Korea</option>
                    <option value="south_sudan">South Sudan</option>
                    <option value="spain">Spain</option>
                    <option value="sri_lanka">Sri Lanka</option>
                    <option value="sudan">Sudan</option>
                    <option value="suriname">Suriname</option>
                    <option value="sweden">Sweden</option>
                    <option value="switzerland">Switzerland</option>
                    <option value="syria">Syria</option>
                    <option value="taiwan">Taiwan</option>
                    <option value="tajikistan">Tajikistan</option>
                    <option value="tanzania">Tanzania</option>
                    <option value="thailand">Thailand</option>
                    <option value="timor_leste">Timor-Leste</option>
                    <option value="togo">Togo</option>
                    <option value="tonga">Tonga</option>
                    <option value="trinidad_and_tobago">Trinidad and Tobago</option>
                    <option value="tunisia">Tunisia</option>
                    <option value="turkey">Turkey</option>
                    <option value="turkmenistan">Turkmenistan</option>
                    <option value="tuvalu">Tuvalu</option>
                    <option value="uganda">Uganda</option>
                    <option value="ukraine">Ukraine</option>
                    <option value="united_arab_emirates">United Arab Emirates (UAE)</option>
                    <option value="united_kingdom">United Kingdom (UK)</option>
                    <option value="united_states_of_america">United States of America (USA)</option>
                    <option value="uruguay">Uruguay</option>
                    <option value="uzbekistan">Uzbekistan</option>
                    <option value="vanuatu">Vanuatu</option>
                    <option value="vatican_city">Vatican City (Holy See)</option>
                    <option value="venezuela">Venezuela</option>
                    <option value="vietnam">Vietnam</option>
                    <option value="yemen">Yemen</option>
                    <option value="zambia">Zambia</option>
                    <option value="zimbabwe">Zimbabwe</option>
                </select>

                <?php if($errors->has('country')): ?>
        <div class="error">
            <?php echo e($errors->first('country')); ?>

        </div>
        <?php endif; ?>
            </div>
            <div class="col-md-6">
                <label for=""></label>
                <input type="text" class="form-control divide <?php echo e($errors->has('city') ? 'error' : ''); ?>" name="city" id="city" placeholder="City">

                <?php if($errors->has('city')): ?>
        <div class="error">
            <?php echo e($errors->first('city')); ?>

        </div>
        <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="row">
        <span class="require">*</span>
        <input type="text" class="form-control <?php echo e($errors->has('organization') ? 'error' : ''); ?>" name="organization" id="organization" placeholder="Organization" required>

        <?php if($errors->has('organization')): ?>
        <div class="error">
            <?php echo e($errors->first('organization')); ?>

        </div>
        <?php endif; ?>
        </div>
    </div>

    <div class="form-group">
        <div class="row">
        <span class="require">*</span>
        <input type="text" class="form-control <?php echo e($errors->has('subject') ? 'error' : ''); ?>" name="subject"
            id="subject" placeholder="Subject" required>

        <?php if($errors->has('subject')): ?>
        <div class="error">
            <?php echo e($errors->first('subject')); ?>

        </div>
        <?php endif; ?>
        </div>
    </div>

    <div class="form-group">
        <div class="row">
        <span class="require">*</span>
        <textarea class="form-control <?php echo e($errors->has('message') ? 'error' : ''); ?>" name="message" id="message"
            rows="4" placeholder="Message"  required></textarea>

        <?php if($errors->has('message')): ?>
        <div class="error">
            <?php echo e($errors->first('message')); ?>

        </div>
        <?php endif; ?>
        </div>
    </div>

    <div class="form-group">
            <p><strong>NOTE: </strong><span class="require">*</span> Fields are required</p>
            <div class="d-flex">
            <input type="checkbox" name="terms" id="terms" class="mt-1 mr-2" required> <p>By submitting the information above, I have read and agreed with the company's <a href="/policy"><strong>Policy.</strong></a></p>
            </div>
    </div>

    <input type="submit" name="send" value="Submit" class="btn contact-btn btn-block">
</form>
        </div>
    </section>
        <footer class="footer1 pt-5 pb-5">
            <div class="container">
                <div class="row">
                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                    <div class="col-md-3">
                        <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne" style="width: 250px">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">What we do</a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
                        <ul class="lists" id="demo">
                            <li class="list-item"><a href="/training" class="text-decoration-none text-white">Training
                                    and Capacity Development</a></li>
                            <li class="list-item"><a href="/health" class="text-decoration-none text-white">Health Care and Related Consultancy services</a></li>
                            <li class="list-item"><a href="/research"
                                    class="text-decoration-none text-white">Market Access and Outcomes Research</a></li>
                            <li class="list-item"><a href="/screen" class="text-decoration-none text-white">Program Management and advisory services</a></li>
                        </ul>
                    </div>
    </div>
  </div>
  </div>
                    <div class="col-md-3">
                        <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingTwo" style="width: 250px">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Our Experience
           </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body">
                        <ul class="lists" id="dem">
                            <li class="list-item">Anglophone Africa (Nigeria, Ghana, Ethiopia, Sierra Leone, Kenya, Uganda, Tanzania, South Africa) </li>
                            <li class="list-item">Lusophone African (Mozambique and Angola) </li>
                            <li class="list-item">Francophone African (Cameron, Benin Republic, Rwanda)</li>
                        </ul>
                    </div>
    </div>
  </div>
  </div>
                    <div class="col-md-3">
                        <input type="email" class="sub-input form-control" placeholder="Email"><button class="btn btn-primary w-100 text-white">Subscribe</button>
                    </div>
                    <div class="col-md-3">
                        <h4>Our Contact Information</h4>
                        <p>
                            Phone: +2348063280360 (Call hours 8-5pm)<br>
                            Location: Lagos, Nigeria.<br>
                            Email: support@grayscaleintl.com
                        </p>
                    </div>

  </div>
                </div>
            </div>
        </footer>
        <footer class="footer2">
            <strong> &copy; <?php echo e(date('Y')); ?> Grayscale Intl || <a href="/policy" class="text-decoration-none">Our
                    Policy</a> || created by <a href="https://favalcodes.herokuapp.com"
                    class="text-decoration-none">Faviolla</a></strong>
        </footer>
    </div>
    <script>

$(".panel-heading").parent('.panel').hover(
  function() {
    $(this).children('.collapse').collapse('show');
  }, function() {
    $(this).children('.collapse').collapse('hide');
  }
);
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\grayscale\resources\views/layouts/app.blade.php ENDPATH**/ ?>