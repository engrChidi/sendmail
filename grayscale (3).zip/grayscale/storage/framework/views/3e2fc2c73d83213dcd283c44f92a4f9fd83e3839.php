

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">

              <h4>Hi, jpr!</h4>
 
<p>


Thank you for completing your registration for the entrepreneurship Masterclass in medical imaging and radiation therapy (MIRT) .
<div>
You can now proceed to join the free masterclass session online by using this zoom link: [time; date]
</div><p>
Kindly be informed that our team of experts are undertaking a study to profile the business landscape of medical imaging and radiation therapy across Africa. 
Your participation is precious to us. We confirm that the information you provide will be kept confidential and anonymous. Follow this link to complete this 10minutes survey.  <br>
<a href="https://grayscaleintl.com/survy" class="btn btn-outline-primary"><u>GrayScaleIntl Survey</u></a>.
</p>
<div>
We thank you for your interest in the GSI Master Class Program.
</div>

<p><i>Best Regards</i></p>
<div>
Uduak Mkpang
</div> <img src="http://codespace.com.ng/img/udulog.png" class="img img-thumbnail"/>
<div>
    
</div>
</p>
    </div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/arv.blade.php ENDPATH**/ ?>