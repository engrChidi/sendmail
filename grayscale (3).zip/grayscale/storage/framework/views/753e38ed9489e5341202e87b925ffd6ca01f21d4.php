

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1" style="margin:auto"><br>
                <h4>Professional Development Mentorship Program (AMP) </h4>

                <p align="center" style="width:400px; padding:10px"><br>
                    <a href="/trainingreg" class="form-control btn btn-outline-primary" style="color:blue"> Register for the MasterClass Webinar </a>
                   
                    </p>
             <p align="center" style="width:400px; padding:10px">
                    <a href="/trainingreg" class="form-control btn btn-outline-dark"> Register for the main MasterClass Webinar </a>
                   
                    </p>
              <p align="center" style="width:400px; padding:10px">
                    <a href="/survy" class="form-control btn btn-outline-success" style="color:blue">  Please Take Our Survey </a>
                    </p>
                      <p align="center" style="width:400px; padding:10px">
                    <a href="/sub" class="form-control btn btn-outline-dark">  Subscribe for Updates </a>
                    </p>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/mid.blade.php ENDPATH**/ ?>