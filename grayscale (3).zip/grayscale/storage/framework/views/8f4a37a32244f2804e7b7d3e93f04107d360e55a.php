<?php $__env->startSection('content'); ?>

    <div class="icon-bar">
        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
        <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
        <a href="mailto:support@grayscaleintl.com" class="youtube"><i class="fa fa-envelope"></i></a>
    </div>

<section class="about" id="about">
        <div class="container">
                <h3><strong>Consulting Services</strong></h3><br>
                <div class="row">
                        <div class="col-md-6">
                                <img src="<?php echo e(asset('images/health.jpeg')); ?>" alt="health" class="health-img">
                        </div>
                        <div class="col-md-6">
                        <p>GSI is your preferred partner with experience and discipline in the following areas:
                       
                        <ol>
                                <li>Solutions development and implementation</li>
<li>Health technologies integration</li>
<li>Integrating health solutions as routine service expectations or products</li>
<li>Scale-up of pilot programs (advisory and program implementation) leading to fully devolved interventions</li></ol>
Our value for partnerships and experience and skill sharing opens us to deliver within a consortium model or as an outsourced partner.
<br>
<a href="#"><u><i>Click here for more enquiries</u></i></a>
                </p>
                        </div>
                </div><br>
        </div>
</section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/pages/health.blade.php ENDPATH**/ ?>