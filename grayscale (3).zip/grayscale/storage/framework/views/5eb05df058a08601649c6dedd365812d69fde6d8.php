<?php $__env->startSection('content'); ?>
    <div class="container">
    <a href="/project" class="btn btn-default text-decoration-none">Go Back</a>
    <h1><?php echo e($project->title); ?></h1>
    <div class="row mt-2 mb-4">
        <div class="col-md-12">
        <img src="/storage/cover_images/<?php echo e($project->cover_image); ?>" alt="" style="width: 100%; height:400px; object-fit: contain">
        </div>
    </div>
    <p class="pl-3 pr-3"><?php echo e($project->body); ?></p>
    <hr>
    <small>Written at <?php echo e($project->created_at); ?></small>

    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $project->user_id): ?>
            <hr>
            <div class="row">
                <div class="col-md-6">
            <a href="/project/<?php echo e($project->id); ?>/edit" class="btn btn-success">Edit</a>
                </div>
                <div class="col-md-6">
            <?php echo Form::open(['action' => ['ProjectController@destroy', $project->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grayscal/grayscale/resources/views/projects/show.blade.php ENDPATH**/ ?>