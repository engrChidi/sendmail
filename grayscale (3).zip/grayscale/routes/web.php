<?php

use App\Post;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Supp;

use App\Mail\Autosresp;
use Illuminate\Support\Facades\Mail;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/send-mail', function () {
    Mail::to('chidex15@yahoo.com')->send(new Autosresp()); 
    return 'A message has been sent to Mailtrap!';
});
Route::resource('survy','SurvyController');
Route::get('/', 'PagesController@index');
Route::get('/mentors', 'PagesController@mentors');
Route::get('/mid', 'PagesController@mid');
Route::get('/sub', 'PagesController@subb');
Route::get('/cdetails', 'PagesController@cdetails');
Route::get('/homy', 'PagesController@homy');
Route::get('/about', 'PagesController@about');
Route::get('/training', 'PagesController@training');
Route::get('/health', 'PagesController@health');
Route::get('/research', 'PagesController@research');
Route::get('/radio', 'PagesController@radio');
Route::get('/surv', 'PagesController@surv');
Route::get('/themsg', 'PagesController@themsg');
Route::get('/screen', 'PagesController@screen');
Route::get('/services', 'PagesController@services');
Route::get('/expert', 'PagesController@expert');
Route::get('/policy', 'PagesController@policy');
Route::get('/leader', 'PagesController@leadership');
Route::get('/academic', 'PagesController@academic');
Route::get('/event', 'PagesController@event');
Route::get('/entrep', 'PagesController@entrepreneurship');
Route::get('/trainingreg', 'PagesController@trainingform');
Route::get('/admin', 'PagesController@admin');
Route::get('/theadmin', 'PagesController@theadmin');
Route::get('/service', 'PagesController@service');
Route::resource('contacts', 'ContactUsFormController');
Route::resource('training', 'TrainingController');
// Post form data
// Route::get('/contact', 'ContactController@contactUs')->name('contactUs');
Route::post('/contact', 'ContactUsFormController@contactUsForm');

Route::post('contact-us', 'ContactUsController@contactUsPost');

/*
Route::get('/hello', function () {
    return '<h1>Hello World!</h1>';
});

 
Route::post('/contact', function (Request $request) {
    //
});*/
Route::get('/users/{id}', function ($id) {
    return 'This is a user ' . $id;
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('post', 'PostsController');
//Route::resource('event', 'EventController');
Route::resource('project', 'ProjectController');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('newsletter','NewsletterController@create');
Route::post('newsletter','NewsletterController@store');
